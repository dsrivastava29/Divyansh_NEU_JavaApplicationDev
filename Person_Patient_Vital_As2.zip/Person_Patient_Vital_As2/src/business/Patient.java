/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business;

import java.util.Date;

/**
 * Patient Info
 *
 * @author Divyansh
 */
public class Patient {

    private String name;
    private int PatientId;
    private Date dob;
    private String primaryDoctor;
    private String prefPharmacy;
    private String race;
    private String ethnicity;

    @Override
    public String toString() {
        return "" + PatientId;
    }

    public String getRace() {
        return race;
    }

    public void setRace(String race) {
        this.race = race;
    }

    public String getEthnicity() {
        return ethnicity;
    }

    public void setEthnicity(String ethnicity) {
        this.ethnicity = ethnicity;
    }
    private VitalSignHistory vitalSignList;

    public Patient() {
        this.vitalSignList = new VitalSignHistory();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPatientId() {
        return PatientId;
    }

    public void setPatientId(int PatientId) {
        this.PatientId = PatientId;
    }

    public Date getDob() {
        return dob;
    }

    public void setDob(Date dob) {
        this.dob = dob;
    }

    public String getPrimaryDoctor() {
        return primaryDoctor;
    }

    public void setPrimaryDoctor(String primaryDoctor) {
        this.primaryDoctor = primaryDoctor;
    }

    public String getPrefPharmacy() {
        return prefPharmacy;
    }

    public void setPrefPharmacy(String prefPharmacy) {
        this.prefPharmacy = prefPharmacy;
    }

    public VitalSignHistory getVitalSignList() {
        return vitalSignList;
    }

    public void setVitalSignList(VitalSignHistory vitalSignList) {
        this.vitalSignList = vitalSignList;
    }

}

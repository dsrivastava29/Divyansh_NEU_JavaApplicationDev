/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business.Donor;

import Business.Employee.Employee;
import com.keepautomation.barcode.BarCode;
import java.awt.image.BufferedImage;

/**
 * Donor
 *
 * @author Divyansh
 */
public class Donor extends Employee {

    private int age;
    private String sex;
    private String disease;
    private BufferedImage qrImage;

    public BarCode getBarcode() {
        return barcode;
    }

    public BufferedImage getQrImage() {
        return qrImage;
    }

    public void setQrImage(BufferedImage qrImage) {
        this.qrImage = qrImage;
    }

    public void setBarcode(BarCode barcode) {
        this.barcode = barcode;
    }
    private String bloodGroup;
    private BarCode barcode;

    @Override
    public String toString() {
        return super.getName();
    }

    public void setName(String name) {
        super.setName(name);
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getDisease() {
        return disease;
    }

    public void setDisease(String disease) {
        this.disease = disease;
    }

    public String getBloodGroup() {
        return bloodGroup;
    }

    public void setBloodGroup(String bloodGroup) {
        this.bloodGroup = bloodGroup;
    }

}

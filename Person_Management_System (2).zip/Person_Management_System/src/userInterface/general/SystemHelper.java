/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package userInterface.general;

import business.EcoSystem;
import business.enterprise.Enterprise;
import business.enterprise.HealthEnterprise;
import business.enterprise.StateEnterprise;
import business.network.Network;
import business.organization.CitizenOrganization;
import business.organization.DoctorOrganization;
import business.organization.Organization;
import business.roles.Role;
import business.users.UserAccount;
import java.util.Calendar;
import java.util.Date;
import javax.swing.JOptionPane;

/**
 *
 * @author Divyansh
 */
public class SystemHelper {

    /**
     *
     * @param network
     * @param userName
     * @return
     */
    public static UserAccount getUser(Network network, String userName) {
        UserAccount userAccount = null;
        try{
        for (Enterprise e : network.getEnterpriseDirectory().getEnterpriseList()) {
            if (e instanceof StateEnterprise) {
                System.out.println("Systemhelper getUSer");
                System.out.println(e);
                for (Organization o : ((StateEnterprise) e).getOrganizationDirectory().getOrganizationList()) {
                    if (o instanceof CitizenOrganization) {
                        System.out.println(o);
                        userAccount = ((CitizenOrganization) o).findCitizen(userName);
                        if (userAccount != null) {
                            System.out.println("ID "+userAccount.getMyPerson().getPersonId());
                            return userAccount;
                        }
                    }
                }
            }
        }
        }
        catch(Exception e){
            System.out.println("Could not get the user");
        }
        return userAccount;
    }

    /**
     *
     * @param enter
     * @param userName
     * @return
     */
    public static UserAccount getUser(Enterprise enter, String userName) {
        UserAccount userAccount = null;
        try {
            for (Organization o : enter.getOrganizationDirectory().getOrganizationList()) {
                if (o instanceof CitizenOrganization) {
                    System.out.println(o);
                    userAccount = ((CitizenOrganization) o).findCitizen(userName);
                    if (userAccount != null) {
                        return userAccount;
                    }
                }
            }
        } catch (Exception e) {
            return null;
        }
        return userAccount;
    }

    public static UserAccount getUserInOrg(Organization checkThisEnter, String uName) {
        UserAccount userAccount = null;
        try {
            for (UserAccount ua : checkThisEnter.getUserAccountDirectory().getUserAccountList()) {
                if (uName.equals(ua.getUsername())) {
                    userAccount = ua;
                    break;
                }
            }
        } catch (Exception e) {
            return userAccount;
        }
        return userAccount;
    }

    public static Date getRoleStartDate(UserAccount u, Role.RoleType roleType) {
        Date dt = null;
        try{
        for (Role r : u.getMyPerson().getMyRoles().getLifeRoles()) {
            if (r.getType().equals(roleType)) {
                dt = r.getStartDate();
            }
        }
        }
        catch(Exception e){
            System.out.println("Problem getting the role start date");
        }
        return dt;
    }

    public static Organization getDoctorOrg(Organization organization, HealthEnterprise healthEnterprise, UserAccount user) {
        try{
        for (Organization o : healthEnterprise.getOrganizationDirectory().getOrganizationList()) {
            if ((o instanceof DoctorOrganization)) {
                for (UserAccount u : ((DoctorOrganization) o).getUserAccountDirectory().getUserAccountList()) {
                    if (u.equals(user)) {
                        organization = o;
                        break;
                    }
                }
            }
        }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null,"Doctor organziation not found");
        }
        return organization;

    }

    public static Enterprise getHealthEnterprise(Enterprise enterprise, EcoSystem business) {
        String entName = enterprise.getName();
        try{
        Network selNet = null;
        for (Network n : business.getNetworkList()) {
            for (Enterprise e : n.getEnterpriseDirectory().getEnterpriseList()) {
                if (e.equals(enterprise)) {
                    selNet = n;
                }
            }
        }
        if (selNet != null) {
            for (Enterprise e : selNet.getEnterpriseDirectory().getEnterpriseList()) {
                System.out.println(e + " " + e.getEnterpriseType() + " " + e.getType());
                if (e.getEnterpriseType().equals(Enterprise.EnterpriseType.Health)) {
                    if (e.getName().equals(entName)) {
                        enterprise = e;
                        System.out.println(e + " " + e.getName());
                        break;
                    }
                }
            }
        }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null,"Health Enterprise not found");
        }
        return enterprise;
    }

    public static long calculateAge(Date dob) {
        try{
        long timeDiff = 0;
        timeDiff = Calendar.getInstance().getTimeInMillis() - dob.getTime();
        return (timeDiff / (365L * 24 * 60 * 60 * 1000));
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null,"Problem calculating the age");
            return 0;
        }
        
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package userInterface.general;

import business.general.Appointment;
import business.users.UserAccount;
import business.workque.AppointmentRequest;
import business.workque.WorkRequest;
import constants.Constants;

/**
 *
 * @author Divyansh
 */
public class RequestMaker {

    public static boolean scheduleAppt(UserAccount sender, UserAccount reciever, String msg, String RequestType) {
        try {
            AppointmentRequest appt = new AppointmentRequest(RequestType);
            Appointment ap = sender.getMyPerson().getHealthInfo().createAppointment();
            appt.setSender(sender);
            appt.setReceiver(sender.getMyPerson().getHealthInfo().getDoctorName());
            appt.setStatus(Constants.PENDING);
            appt.setMessage(Constants.APPOINTMENTMSG);
            ap.setSenderNote(msg);
            sender.getMyWorkQueue().getWorkList().add(appt);
            reciever.getMyWorkQueue().getWorkList().add(appt);
        } catch (Exception e) {
            return false;
        }
        return true;
    }

    public static int getWorkCount(UserAccount requester, UserAccount reciever) {
        int count = 0;
        try{
        for (WorkRequest w : requester.getMyWorkQueue().getWorkList()) {
            if (w.getReceiver().equals(reciever)) {
                if (!(w.getStatus().equals(Constants.DONE))) {
                    count++;
                }
            }
        }
        }
        catch(Exception e){
            System.out.println("could not get the count");
        }
        return count;
    }
}

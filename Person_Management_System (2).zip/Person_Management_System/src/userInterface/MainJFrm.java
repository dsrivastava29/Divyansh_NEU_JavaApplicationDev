/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package userInterface;

import business.EcoSystem;
import business.enterprise.Enterprise;
import business.family.FamilyDirectory;
import business.family.FamilyInfo;
import business.organization.Organization;
import business.users.UserAccount;
import business.workque.WorkRequest;
import constants.Constants;
import controls.DB4OUtil;
import userInterface.helper.HeadTitle;
import userInterface.helper.*;
import userInterface.helper.UIHelper;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import userInterface.appUser.Connections;
import userInterface.appUser.Home;
import userInterface.appUser.Interfaces;
import userInterface.appUser.Reports;
import userInterface.appUser.Settings;
import userInterface.calenderScheduling.MainRoutineWindow;

/**
 *
 * @author Divyansh
 */
public class MainJFrm extends javax.swing.JFrame {

    /**
     * Creates new form MainJFrm
     */
    //UI vars
    public static int mainWindowId = 0;

    /**
     *
     */
    public static Dimension originalSize;

    /**
     *
     */
    public int mainId;
    private int mainId2;

    /**
     *
     */
    public static boolean undecorated = false;

    /**
     * keep login track
     */
    public boolean isLoggedIn = false;
    HeadTitle head;
    private JPanel right;
    private UserAccount currentUser;
    private MainRoutineWindow userSchedule;

    //business vars
    private static EcoSystem system = null;
    private DB4OUtil dB4OUtil = DB4OUtil.getInstance();
    private Enterprise currentEnterprise;
    private Organization currentOrg;

    /**
     * The main JFrame window for application
     */
    public MainJFrm() {
        //Business
        try {
            if (system == null) {
                system = dB4OUtil.retrieveSystem();
                WorkRequest.count=system.getWorkReqCount();
                UserAccount.count=system.getUserCount();
                FamilyDirectory.count=system.getfamilyCount();
            }
        } catch (Exception e) {
            System.out.println("DB4O retrieve error");
        }
        currentUser = null;
        currentEnterprise = null;
        currentOrg = null;
        isLoggedIn = false;

        //UI
        right = null;
        setUndecorated(undecorated);
        this.setMinimumSize(new Dimension(1000, 1000));
        originalSize = this.getSize();
        initComponents();
        appProcessContainer.setSize(1000, 600);
        mainId = 0;
        mainId2=0;
        head = new HeadTitle();
        JPanel menuLine = new JPanel(new FlowLayout(FlowLayout.LEFT, 2, 2));
        menuLine.setBackground(Color.WHITE);
        appSplitPane.setLeftComponent(menuLine);
        this.menuLine = menuLine;
        try {
            setWindowChangedEvent(mainId);
            setMouseListener();
            setMenuBar();
            setHeadTitle();
            setButtons();
        } catch (Exception e) {
            System.out.println("setting up error");
        }
    }

    /**
     * return the ecosystem instance
     * @return
     */
    public EcoSystem getSystem() {
        return system;
    }
public void setId(){
mainId2=2;
}
    private void setMenuBar() {
        jMenuBar1.add(Box.createHorizontalGlue());
        JMenu about = new JMenu("About");
        about.setFont(new Font("Segoe UI", Font.PLAIN, 024));
        about.setMnemonic('B');
        JMenuItem aboutItem = new JMenuItem("About Project");
        aboutItem.setFont(new Font("Segoe UI", Font.PLAIN, 024));
        aboutItem.setMnemonic('B');
        aboutItem.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, Constants.ABOUTNOTE);
            }
        });
        about.add(aboutItem);
        jMenuBar1.add(about);
    }

    private void setHeadTitle() {
        JPanel p;
        if (isLoggedIn && currentUser != null) {
            head.updateTitle(currentUser.getMyPerson().getBasicInfo().getFirstName());
        } else {
            p = head.getPanel();
            p.setOpaque(false);
            jPanel1.add(p);
        }

    }

    private void setButtons() {
        this.menuLine.setSize(this.getWidth(), this.getHeight() / 20);
        if (isLoggedIn) {
            userSchedule = new MainRoutineWindow(String.valueOf(currentUser.getMyPerson().getPersonId()));
            userSchedule.setVisible(true);
            userSchedule.setVisible(false);
            mainId++;
        } else {
            mainId = 0;
        }
        for (JButton j : UIHelper.getMenuButtonsForUser(mainId)) {
            menuLine.add(j);
        }
        Component[] cp = menuLine.getComponents();
        for (int i = 0; i < cp.length; i++) {
            if (cp[i] instanceof JButton) {
                addButtonAction(cp[i]);
                JButton j = (JButton) cp[i];
                Dimension d = j.getPreferredSize();
                d.height = this.getHeight() / 6;// menuLine.getHeight()-10;//e.getComponent().getHeight() / 7;
                d.width = menuLine.getWidth() / 7 + 15;
                j.setPreferredSize(d);
            }
        }
        
    }

    void loginSuccess(UserAccount userAccount, Organization myOrganization, Enterprise myEnterprise) {
        try {
            isLoggedIn = true;
            this.currentUser = userAccount;
            this.currentEnterprise = myEnterprise;
            this.currentOrg = currentOrg;

            setHeadTitle();
            Component[] cp = menuLine.getComponents();
            for (int i = 0; i < cp.length; i++) {
                if (cp[i] instanceof JButton) {
                    System.out.println("bt" + cp[i].getName());
                    menuLine.remove(cp[i]);
                }
            }
            JPanel menuLine = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
            menuLine.setBackground(Color.WHITE);
            menuLine.setSize(this.menuLine.getSize());
            this.menuLine = menuLine;

            setButtons();
            appSplitPane.setLeftComponent(menuLine);
            //userSchedule.setVisible(true);
        } catch (Exception e) {
            System.out.println("Login success problem");
        }

    }

    /**
     * Log out the user 
     */
    public void loggedOut() {
        try {
            isLoggedIn = false;
            dB4OUtil.storeSystem(system);
            head.reverseTitle();
            System.out.println("out");
            Component[] cp = menuLine.getComponents();
            for (int i = 0; i < cp.length; i++) {
                if (cp[i] instanceof JButton) {
                    System.out.println("bt" + cp[i].getName());
                    menuLine.remove(cp[i]);
                }
            }
            JPanel menuLine = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
            menuLine.setBackground(Color.WHITE);
            menuLine.setSize(this.menuLine.getSize());
            this.menuLine = menuLine;
            setButtons();
            appSplitPane.setLeftComponent(menuLine);
            appSplitPane.setDividerLocation(this.getHeight() / 6);
        } catch (Exception e) {
            System.out.println("logged out error occured");
        }
    }

    /**
     * Add button sound
     */
    private void addButtonAction(Component component) {
        try {
            JButton j = (JButton) component;
            URL url = this.getClass().getResource(Constants.CLICK_SOUND);
            j.addActionListener(new ActionListener() {

                @Override
                public void actionPerformed(ActionEvent e) {
                    AudioInputStream audioInputStream = null;
                    try {
                        //Toolkit.getDefaultToolkit().beep();
                        audioInputStream = AudioSystem.getAudioInputStream(new File(url.getPath()).getAbsoluteFile());
                        Clip clip = null;
                        try {
                            clip = AudioSystem.getClip();
                        } catch (LineUnavailableException ex) {
                            Logger.getLogger(MainJFrm.class.getName()).log(Level.SEVERE, null, ex);
                        }
                        clip.open(audioInputStream);
                        clip.start();
                        loadAppProcessContainer(j.getName());
                    } catch (UnsupportedAudioFileException ex) {
                        Logger.getLogger(MainJFrm.class.getName()).log(Level.SEVERE, null, ex);
                    } catch (IOException ex) {
                        Logger.getLogger(MainJFrm.class.getName()).log(Level.SEVERE, null, ex);
                    } catch (LineUnavailableException ex) {
                        Logger.getLogger(MainJFrm.class.getName()).log(Level.SEVERE, null, ex);
                    } finally {
                        try {
                            audioInputStream.close();
                        } catch (IOException ex) {
                            Logger.getLogger(MainJFrm.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }
                }
            });
        } catch (Exception e) {
            System.out.println("Adding sound on button probelem");
        }
    }

    /**
     * Load application work area for login or user
     */
    private void loadAppProcessContainer(String name) {
        try {
            right = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
            right.setSize(appProcessContainer.getSize().width, appProcessContainer.getSize().height);
            switch (name) {
                case Constants.LOGIN:
                    LoginPanel login = new LoginPanel(this, appProcessContainer);
                    right.add(login);

                    break;
                case Constants.REGISTER:
                    NewUser newUser = new NewUser(this, appProcessContainer, system);
                    right.add(newUser);

                    break;
                case Constants.HOME:
                    //DoctorOrganization docOrg
                    Home home = new Home(this, appProcessContainer, currentUser, userSchedule, system.getNetworkByName(currentUser.getMyPerson().getBasicInfo().getCountry()));
                    home.setSize(right.getSize().width, right.getSize().height);
                    right.add(home);

                    break;
                case Constants.CONNECTION:
                    Connections conx = new Connections(this, appProcessContainer, currentUser, currentOrg, currentEnterprise);
                    right.add(conx);

                    break;
                case Constants.REPORT:
                    Reports r = new Reports(this, appProcessContainer, currentUser);
                    right.add(r);
                    break;
                case Constants.INTERFACES:
                    Interfaces myInterface = new Interfaces(this, appProcessContainer, currentUser, system, currentEnterprise, currentOrg);
                    right.add(myInterface);
                    break;
                case Constants.SETTING:
                    Settings s = new Settings(this, appProcessContainer, currentUser);
                    right.add(s);
                    break;

                case Constants.LOGOUT:
                    loggedOut();
                    break;

            }

            right.setOpaque(false);
            appProcessContainer.add("Login", right);
            CardLayout layout = (CardLayout) appProcessContainer.getLayout();
            layout.next(appProcessContainer);
        } catch (Exception e) {
            System.out.println("Problem in setting up button");
        }
    }

    /**
     * Sets up window change events
     * @param mainId
     */
    public void setWindowChangedEvent(int mainId) {
        try {
            this.addWindowListener(new WindowAdapter() {
                @Override
                public void windowClosing(WindowEvent e) {
                    super.windowClosing(e);
                    exitApp();
                }

            });
            ComponentListener cmpListen;
            cmpListen = new ComponentListener() {
                @Override
                public void componentResized(ComponentEvent e) {
                    Dimension size = e.getComponent().getSize();
                    appSplitPane.setDividerLocation(e.getComponent().getHeight() / 6);
                    Component[] cp = menuLine.getComponents();
                    for (int i = 0; i < cp.length; i++) {
                        if (cp[i] instanceof JButton) {
                            updateSize(cp[i], e);
                        }
                    }

                }

                @Override
                public void componentMoved(ComponentEvent e) {
                    e.getID();
                }

                @Override
                public void componentShown(ComponentEvent e) {
                    e.getID();
                }

                @Override
                public void componentHidden(ComponentEvent e) {
                    e.getID();
                }

                private void updateSize(Component component, ComponentEvent e) {
                    if (component instanceof JButton) {
                        JButton j = (JButton) component;
                        Dimension d = j.getPreferredSize();
                        d.height = e.getComponent().getHeight() / 6;// menuLine.getHeight()-10;//e.getComponent().getHeight() / 7;
                        d.width = menuLine.getWidth() / 7 + 15;
                        j.setPreferredSize(d);
                    }

                }
            };
            this.addComponentListener(cmpListen);
        } catch (Exception e) {
            System.out.println("window event failed");
        }
    }

    private void setMouseListener() {
        MoveMouseListener mlistener = new MoveMouseListener(jMenuBar1);
        jMenuBar1.addMouseListener(mlistener);
        jMenuBar1.addMouseMotionListener(mlistener);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        appSplitPane = new javax.swing.JSplitPane();
        menuLine = new javax.swing.JPanel();
        appProcessContainer = new javax.swing.JPanel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuItem3 = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();
        jMenuItem2 = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(153, 153, 0));

        jPanel1.setBackground(new java.awt.Color(200, 15, 15));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jPanel2.setBackground(new java.awt.Color(200, 15, 15));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel1.setFont(new java.awt.Font("Tahoma", 3, 18)); // NOI18N
        jLabel1.setText("Copyright @Crazydiv 2015");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 284, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel3.setBackground(new java.awt.Color(238, 237, 204));
        jPanel3.setLayout(new javax.swing.BoxLayout(jPanel3, javax.swing.BoxLayout.LINE_AXIS));

        appSplitPane.setDividerSize(0);
        appSplitPane.setOrientation(javax.swing.JSplitPane.VERTICAL_SPLIT);
        appSplitPane.setOpaque(false);

        menuLine.setBackground(new java.awt.Color(255, 255, 255));
        menuLine.setPreferredSize(new java.awt.Dimension(1218, 70));
        menuLine.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEADING, 3, 3));
        appSplitPane.setTopComponent(menuLine);

        appProcessContainer.setBackground(new java.awt.Color(238, 237, 204));
        appProcessContainer.setLayout(new java.awt.CardLayout());
        appSplitPane.setRightComponent(appProcessContainer);

        jPanel3.add(appSplitPane);

        jMenuBar1.setBackground(new java.awt.Color(200, 15, 15));
        jMenuBar1.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N

        jMenu1.setMnemonic('F');
        jMenu1.setText("File");
        jMenu1.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N

        jMenuItem1.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jMenuItem1.setMnemonic('N');
        jMenuItem1.setText("New Window");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem1);

        jMenuItem3.setText("BorderLess");
        jMenuItem3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem3ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem3);

        jMenuBar1.add(jMenu1);

        jMenu2.setMnemonic('E');
        jMenu2.setText("Exit");
        jMenu2.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N

        jMenuItem2.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jMenuItem2.setMnemonic('E');
        jMenuItem2.setText("Exit");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        jMenu2.add(jMenuItem2);

        jMenuBar1.add(jMenu2);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(0, 0, 0)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        // TODO add your handling code here:
        try {
            MainJFrm mainJFrm = null;
            mainJFrm = new MainJFrm();
            mainJFrm.setId();
            mainJFrm.setVisible(true);
        } catch (Exception e) {
            System.out.println("New instance launch problem");
        }
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
        // TODO add your handling code here:
        try {
            exitApp();
        } catch (Exception e) {
            System.out.println("Exit not occured properly");
        }
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void jMenuItem3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem3ActionPerformed
        // TODO add your handling code here:

    }//GEN-LAST:event_jMenuItem3ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MainJFrm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MainJFrm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MainJFrm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MainJFrm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MainJFrm().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel appProcessContainer;
    private javax.swing.JSplitPane appSplitPane;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel menuLine;
    // End of variables declaration//GEN-END:variables

    private void exitApp() {
        try {
            system.setWorkReqCount(WorkRequest.count);
            system.setUserCount(UserAccount.count);
            system.setfamilyCount(FamilyDirectory.count);
            dB4OUtil.storeSystem(system);
            if (userSchedule != null) {
                userSchedule.dispose();
            }
            if (mainId2 == 0) {
                if (userSchedule != null) {
                    userSchedule.exit();
                }
                System.out.println("main");
                setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                System.exit(1);

            } else {
                System.out.println("Extra");
                //setVisible(false);
                setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                this.dispose();
            }
        } catch (Exception e) {
            System.out.println("Cant exit right now");
        }
    }

}

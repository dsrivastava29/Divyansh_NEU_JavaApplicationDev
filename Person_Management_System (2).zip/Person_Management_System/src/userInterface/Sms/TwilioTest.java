/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package userInterface.Sms;

/**
 *
 * @author Divyansh
 */
// You may want to be more specific in your imports 
import java.util.*;
import com.twilio.sdk.*;
import com.twilio.sdk.resource.factory.*;
import com.twilio.sdk.resource.instance.*;
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

public class TwilioTest {

    // Find your Account Sid and Token at twilio.com/user/account 

    public static final String ACCOUNT_SID = "AC340c04d46618057fbaa835ab7b624f25";
    public static final String AUTH_TOKEN = "3a9c3cbb607de580303003690431d7a9";

    public static void senSms(String toNumber, String text) throws TwilioRestException {
        try {
            TwilioRestClient client = new TwilioRestClient(ACCOUNT_SID, AUTH_TOKEN);

            // Build the parameters 
            List<NameValuePair> params = new ArrayList<NameValuePair>();
            params.add(new BasicNameValuePair("To", toNumber));
            params.add(new BasicNameValuePair("From", "+17816077052"));
            params.add(new BasicNameValuePair("Body", text));

            MessageFactory messageFactory = client.getAccount().getMessageFactory();
            Message message = messageFactory.create(params);
            System.out.println(message.getSid());
        } catch  (Exception e)  {
                System.out.println("Error in message");
            }
        }
    
}

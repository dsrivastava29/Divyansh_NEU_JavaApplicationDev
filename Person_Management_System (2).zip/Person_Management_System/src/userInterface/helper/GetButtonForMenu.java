/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package userInterface.helper;

import constants.Constants;
import java.awt.Font;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import userInterface.MainJFrm;

/**
 *
 * @author Divyansh
 */
public class GetButtonForMenu {

    /**
     * Class to generate menus for main window
     * @param name
     * @return Created button for name
     */
    public static JButton createMenuButton(String name) {
        String imagePath = getPath(name);
        //  String imagePath_hover = getPath(name);
        URL url = GetButtonForMenu.class.getResource(imagePath);
        //  URL url_hover = GetButtonForMenu.class.getResource(imagePath_hover);
        BufferedImage image = null;
        //System.out.println(url.getPath());
        //   BufferedImage image2 = null;
        try {
            image = ImageIO.read(new File(url.getPath()));
            //      image2 = ImageIO.read(new File(url_hover.getPath()));
        } catch (IOException ex) {
            System.out.println("NOT DONE ONE");
            Logger.getLogger(MainJFrm.class.getName()).log(Level.SEVERE, null, ex);
        }
        JButton btn = new JButton(name, new ImageIcon(image));
        btn.setName(name);
        //btn.setPressedIcon(new ImageIcon(image2));
        //btn.setPreferredSize(new Dimension(btn.getSize().getWidth(), btn.getSize().getHeight()));
        btn.setHorizontalTextPosition(SwingConstants.CENTER);
        btn.setVerticalTextPosition(SwingConstants.BOTTOM);
        btn.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 024));
        btn.setBorder(BorderFactory.createEmptyBorder());
        btn.setContentAreaFilled(false);
        return btn;
    }

    private static String getPath(String name) {
        switch (name) {
            case Constants.LOGIN:
                return Constants.IMAGE_LOGIN;
            case Constants.REGISTER:
                return Constants.IMAGE_REGISTER;
            case Constants.HOME:
                return Constants.IMAGE_HOME;
            case Constants.CONNECTION:
                return Constants.IMAGE_CONNECTION;
            case Constants.REPORT:
                return Constants.IMAGE_REPORTS;
            case Constants.INTERFACES:
                return Constants.IMAGE_INTERFACES;
            case Constants.SETTING:
                return Constants.IMAGE_SETTINGS;
            case Constants.LOGOUT:
                return Constants.IMAGE_LOGOUT;
            default:
                return Constants.IMAGE_LOGOUT;
        }
    }

}

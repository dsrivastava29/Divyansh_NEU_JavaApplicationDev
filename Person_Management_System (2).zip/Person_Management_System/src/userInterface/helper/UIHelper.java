/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package userInterface.helper;

import constants.Constants;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import javax.swing.JButton;

/**
 *
 * @author Divyansh
 */
public class UIHelper {

    /**
     *
     * @param mainId
     * @return
     */
    public static ArrayList<JButton> getMenuButtonsForUser(int mainId) {
        ArrayList<JButton> menuButtons = new ArrayList<>();
        ArrayList<String> userMenus = new ArrayList<>();
        if (mainId == 0) {
            userMenus.add(Constants.LOGIN);
            userMenus.add(Constants.REGISTER);
        } else {
            userMenus.add(Constants.HOME);
            userMenus.add(Constants.CONNECTION);
            userMenus.add(Constants.REPORT);
            userMenus.add(Constants.INTERFACES);
            userMenus.add(Constants.SETTING);
            userMenus.add(Constants.LOGOUT);

        }
        for (String s : userMenus) {
            menuButtons.add(GetButtonForMenu.createMenuButton(s));
        }
        return menuButtons;
    }

    public static String checkAndreturnString(Object object) {
        if (object != null) {
            return (String) object;
        } else {
            return "";
        }
    }

    public static Date checkAndreturnDate(Object object) {
        Date dt = Calendar.getInstance().getTime();
        if (object instanceof Date) {
            if (object != null) {
                return (Date) object;
            } else {
                return dt;
            }
        } else {
            return dt;
        }
    }

    /**
     *
     * @param menuClicked
     * @return
     */
    public static ArrayList<JButton> getOptionButtonsForUser(String menuClicked) {
        ArrayList<JButton> menuButtons = new ArrayList<>();
        ArrayList<String> userMenus = new ArrayList<>();
        switch (menuClicked) {
            case Constants.HOME:
                break;
            case Constants.CONNECTION:
                userMenus.add(Constants.ADDNEW);
                userMenus.add(Constants.VIEWCON);
                break;
            case Constants.REPORT:
                break;
            case Constants.INTERFACES:
                break;
            case Constants.SETTING:
                break;
        }

        for (String s : userMenus) {
            menuButtons.add(GetButtonForMenu.createMenuButton(s));
        }
        return menuButtons;
    }
}

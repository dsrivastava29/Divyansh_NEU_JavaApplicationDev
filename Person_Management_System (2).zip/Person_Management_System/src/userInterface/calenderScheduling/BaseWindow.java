/**
 * Copyright (c) 2015, MindFusion LLC - Bulgaria.
 */
package userInterface.calenderScheduling;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.text.html.*;

import com.mindfusion.common.*;
import com.mindfusion.scheduling.GroupType;
import com.mindfusion.scheduling.awt.*;
import com.mindfusion.scheduling.model.*;
import constants.Constants;
import java.io.File;
import java.io.FileNotFoundException;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import static javax.swing.WindowConstants.DISPOSE_ON_CLOSE;

/**
 *
 * @author Divyansh
 */
public abstract class BaseWindow extends JFrame {

    private String user;

    /**
     *
     * @param args
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                MainRoutineWindow window = null;
                try {
                    window = new MainRoutineWindow("");
                    window.setVisible(true);
                } catch (Exception exp) {
                }
            }
        });
    }

    /**
     *
     * @param user
     */
    protected BaseWindow(String user) {
        this.user = user;
        this.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                super.windowClosing(e);
                setDefaultCloseOperation(DISPOSE_ON_CLOSE);
            }

        });

        fileChooser = new JFileChooser();
        calendar = new AwtCalendar();
        try {
            String path = Constants.ROUTINE_LOC;
            URI uri = getClass().getResource(path).toURI();
            File outputFile;
            outputFile = new File(uri.toURL().getPath() + "USER" + user + ".xml");
            calendar.getSchedule().loadFrom(outputFile.getAbsolutePath(), ContentType.Xml);
            if (calendar.getGroupType() != GroupType.None) {
                calendar.beginInit();
                calendar.getContacts().clear();
                calendar.getResources().clear();
                calendar.getLocations().clear();
                calendar.getTasks().clear();
                calendar.getContacts().addAll(calendar.getSchedule().getContacts());
                calendar.getResources().addAll(calendar.getSchedule().getResources());
                calendar.getLocations().addAll(calendar.getSchedule().getLocations());
                calendar.getTasks().addAll(calendar.getSchedule().getTasks());
                calendar.endInit();
            }
        } catch (URISyntaxException ex) {
            Logger.getLogger(BaseWindow.class.getName()).log(Level.SEVERE, null, ex);
        } catch (MalformedURLException ex) {
            Logger.getLogger(BaseWindow.class.getName()).log(Level.SEVERE, null, ex);
        } catch (Exception e) {
            fileChooser = new JFileChooser();
            calendar = new AwtCalendar();
        }
        calendar.setCurrentTime(calendar.getCurrentTime());
        calendar.setDate(new DateTime(2015, 12, 5));
        calendar.setEndDate(new DateTime(2018, 7, 7));

//		label = new JTextPane();
//		label.setBackground(new Color(255, 255, 225));
//		label.setBorder(new LineBorder(Color.orange, 1));
//		label.setEditable(false);
//		label.setEditorKit(new HTMLEditorKit());
//		labelPane = new JScrollPane(label);
//		
        content = new JPanel();
        content.setBackground(new Color(242, 242, 242));
        content.setLayout(new GridLayout(1, 1));
        Container cp = getContentPane();

        JMenuBar menuBar = new JMenuBar();
        JMenu mFile = new JMenu("File");
        JMenuItem mIFOpen = new JMenuItem("Open");
        mIFOpen.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                openFileChooserClicked();
            }
        });

        JMenuItem mIFSave = new JMenuItem("Save");
        mIFSave.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    saveFileChooserClicked();
                } catch (MalformedURLException ex) {
                    Logger.getLogger(BaseWindow.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });

        menuBar.add(mFile);
        mFile.add(mIFOpen);
        mFile.add(mIFSave);

        setJMenuBar(menuBar);

//		SpringLayout layout = new SpringLayout();
//		layout.putConstraint(SpringLayout.WEST, labelPane, 0, SpringLayout.WEST, cp);
//		layout.putConstraint(SpringLayout.NORTH, labelPane, 0, SpringLayout.NORTH, cp);
//		layout.putConstraint(SpringLayout.EAST, labelPane, 0, SpringLayout.EAST, cp);
//		layout.putConstraint(SpringLayout.SOUTH, labelPane, 70, SpringLayout.NORTH, cp);
//
//		layout.putConstraint(SpringLayout.WEST, content, 0, SpringLayout.WEST, cp);
//		layout.putConstraint(SpringLayout.NORTH, content, 70, SpringLayout.NORTH, cp);
//		layout.putConstraint(SpringLayout.EAST, content, 0, SpringLayout.EAST, cp);
//		layout.putConstraint(SpringLayout.SOUTH, content, 0, SpringLayout.SOUTH, cp);
//		
//		cp.setLayout(layout);
//		cp.add(labelPane);
        cp.add(content);
    }

    /**
     *
     * @param value
     */
    public void setInfo(String value) {
        label.setText("<div style=\"padding: 2pt; font-family: Verdana; font-size: 11pt;\">" + value + "</div>");
        label.setCaretPosition(0);
    }

    /**
     *
     * @throws MalformedURLException
     */
    protected void saveFileChooserClicked() throws MalformedURLException {
//		if (fileChooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION)
//		{
        try {
            String path = Constants.ROUTINE_LOC;
            URI uri = getClass().getResource(path).toURI();
            File outputFile;
            outputFile = new File(uri.toURL().getPath() + "USER" + user + ".xml");
            // ImageIO.write(targetImg, "jpg", outputFile);
            calendar.getSchedule().saveTo(outputFile.getAbsolutePath(), ContentType.Xml);
        } catch (URISyntaxException ex) {
            Logger.getLogger(BaseWindow.class.getName()).log(Level.SEVERE, null, ex);
        }
        //}
    }

    /**
     *
     */
    protected void openFileChooserClicked() {
        if (fileChooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            try {
                String path = Constants.ROUTINE_LOC;
                URI uri = getClass().getResource(path).toURI();
                File outputFile;
                outputFile = new File(uri.toURL().getPath() + "USER" + user + ".xml");
                calendar.getSchedule().loadFrom(outputFile.getAbsolutePath(), ContentType.Xml);
                if (calendar.getGroupType() != GroupType.None) {
                    calendar.beginInit();
                    calendar.getContacts().clear();
                    calendar.getResources().clear();
                    calendar.getLocations().clear();
                    calendar.getTasks().clear();
                    calendar.getContacts().addAll(calendar.getSchedule().getContacts());
                    calendar.getResources().addAll(calendar.getSchedule().getResources());
                    calendar.getLocations().addAll(calendar.getSchedule().getLocations());
                    calendar.getTasks().addAll(calendar.getSchedule().getTasks());
                    calendar.endInit();
                }
            } catch (URISyntaxException ex) {
                Logger.getLogger(BaseWindow.class.getName()).log(Level.SEVERE, null, ex);
            } catch (MalformedURLException ex) {
                Logger.getLogger(BaseWindow.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    /**
     *
     */
    public void exit() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        System.exit(EXIT_ON_CLOSE);
    }
    private static final long serialVersionUID = 1L;

    /**
     *
     */
    protected AwtCalendar calendar;
    private JFileChooser fileChooser;

    /**
     *
     */
    protected JPanel content;
    private JTextPane label;
    private JScrollPane labelPane;

    /**
     *
     * @return
     */
    public AwtCalendar getCalendar() {
        return calendar;
    }
}

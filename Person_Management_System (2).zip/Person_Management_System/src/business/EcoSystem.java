/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business;

import business.enterprise.Enterprise;
import business.network.Network;
import business.organization.Organization;
import business.roles.CountryAdminRole;
import business.roles.Role;
import business.roles.SystemAdminRole;
import java.util.ArrayList;

/**
 * Application single instance class
 *
 * @author Divyansh
 */
public class EcoSystem extends Organization {

    private static EcoSystem business;
    private ArrayList<Network> networkList;
    private int familyCount;
    private int workReqCount;
    private int userCount;

    public int getfamilyCount() {
        return familyCount;
    }

    public void setfamilyCount(int familyCount) {
        this.familyCount = familyCount;
    }

    public int getWorkReqCount() {
        return workReqCount;
    }

    public void setWorkReqCount(int workReqCount) {
        this.workReqCount = workReqCount;
    }

    public int getUserCount() {
        return userCount;
    }

    public void setUserCount(int userCount) {
        this.userCount = userCount;
    }

    /**
     * Get the instance of Ecosystem
     *
     * @return
     */
    public static EcoSystem getInstance() {
        if (business == null) {
            business = new EcoSystem();
        }
        return business;
    }

    private EcoSystem() {
        super(null);
        networkList = new ArrayList<>();
    }

    /**
     * Returns all available networks
     *
     * @return
     */
    public ArrayList<Network> getNetworkList() {
        return networkList;
    }

    /**
     * Create new network
     *
     * @return
     */
    public Network createAndAddNetwork() {
        Network net = new Network();
        networkList.add(net);
        return net;
    }

    /**
     * Checks if a network is already present in Ecosystem
     *
     * @param name of the country network
     * @return The instance of Network class
     */
    public boolean isNetworkAvailable(String name) {
        for (Network n : getNetworkList()) {
            if (n.getName().equals(name)) {
                return false;
            }
        }
        return true;
    }

    /**
     *
     * @return
     */
    @Override
    public ArrayList<Role> getSupportedRole() {
        ArrayList<Role> roles = new ArrayList<>();
        roles.add(new SystemAdminRole());
        roles.add(new CountryAdminRole());
        return roles;
    }

    /**
     *
     * @param user
     * @return
     */
    public boolean isUserAvailable(String user) {
        if (this.getUserAccountDirectory().isUserAvailable(user)) {
            for (Network n : networkList) {
                for (Enterprise e : n.getEnterpriseDirectory().getEnterpriseList()) {
                    if (e.getUserAccountDirectory().isUserAvailable(user)) {
                        for (Organization o : e.getOrganizationDirectory().getOrganizationList()) {
                            if (!o.getUserAccountDirectory().isUserAvailable(user)) {
                                return false;
                            }
                        }
                        return true;
                    } else {
                        return false;
                    }
                }
            }
            return true;
        } else {
            return false;
        }
    }

    /**
     *
     * @param net
     * @return
     */
    public Network getNetworkByName(String net) {
        for (Network n : networkList) {
            if (n.getName().equals(net)) {
                return n;
            }
        }
        return null;
    }

    @Override
    public String toString() {
        return "EcoSystem{" + '}' + getNetworkList().size();
    }

}

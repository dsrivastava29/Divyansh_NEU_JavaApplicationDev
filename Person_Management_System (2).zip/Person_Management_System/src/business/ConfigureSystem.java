/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business;

import business.personUnit.BasicInfo;
import business.roles.CitizenRole;
import business.roles.Role;
import business.roles.SystemAdminRole;
import business.users.UserAccount;
import java.util.ArrayList;
import java.util.Calendar;

/**
 *
 * @author Divyansh
 */
public class ConfigureSystem {

    /**
     * Configure the main ecosystem
     *
     * @return The configured ecosystem single instance
     */
    public static EcoSystem configure() {
        EcoSystem system = EcoSystem.getInstance();

        //Create Alpha
        try {
            BasicInfo bi = new BasicInfo();
            bi.setFirstName("crazydiv");
            ArrayList<Role> roles = new ArrayList<>();
            roles.add(new CitizenRole());
            roles.add(new SystemAdminRole());
            for (Role r : roles) {
                r.setStartDate(Calendar.getInstance().getTime());
            }
            UserAccount ecoUser = system.getUserAccountDirectory().createUserAccount("alpha", "alpha", roles, bi);
        } catch (Exception e) {
            System.out.println("initialization problem");
        }
        return system;
    }
}

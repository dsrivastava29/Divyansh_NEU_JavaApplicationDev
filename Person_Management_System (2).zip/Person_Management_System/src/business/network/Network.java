/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business.network;

import business.enterprise.StateEnterprise;
import business.enterprise.Enterprise;
import business.enterprise.EnterpriseDirectory;
import business.enterprise.HealthEnterprise;
import business.organization.CitizenOrganization;
import business.organization.Organization;
import java.util.ArrayList;

/**
 *
 * @author Divyansh
 */
public class Network {

    /**
     * Network within an ecosystem
     */
    private String name;
    private EnterpriseDirectory enterpriseDirectory;
    //private ArrayList<Network> networkDirectory;

    /**
     *
     * @return
     */
    public EnterpriseDirectory getEnterpriseDirectory() {
        return this.enterpriseDirectory;
    }

    /**
     *
     */
    public Network() {
        enterpriseDirectory = new EnterpriseDirectory();
        //  networkDirectory=new ArrayList<>();
    }

    /**
     *
     * @return
     */
    public String getName() {
        return this.name;
    }

    /**
     *
     * @param enterpriseDirectory
     */
    public void setEnterpriseDirectory(EnterpriseDirectory enterpriseDirectory) {
        this.enterpriseDirectory = enterpriseDirectory;
    }

    /**
     *
     * @param name
     */
    public void setName(String name) {
        this.name = name;
    }

    public String toString() {
        return this.name;
    }

    /**
     *
     * @param selState
     * @return
     */
    public boolean isStateAvailable(String selState) {
        for (Enterprise enter : getEnterpriseDirectory().getEnterpriseList()) {
            if ((enter.getName().equals(selState)) && (enter instanceof StateEnterprise)) {
                return false;
            }
        }
        return true;
    }

    public boolean isStateAvailable(String selState, Enterprise.EnterpriseType enterpriseType) {
        for (Enterprise enter : getEnterpriseDirectory().getEnterpriseList()) {
            if ((enter.getName().equals(selState)) && (enter.getEnterpriseType().equals(enterpriseType))) {
                return false;
            }
        }
        return true;
    }

    /**
     *
     * @param selState
     * @return
     */
    public boolean isHealthEntAvailable(String selState) {
        for (Enterprise enter : getEnterpriseDirectory().getEnterpriseList()) {
            if ((enter.getName().equals(selState)) && (enter instanceof HealthEnterprise)) {
                return false;
            }
        }
        return true;
    }

    public CitizenOrganization getComparableCitizenOrganization(Organization reqesting) {
        Enterprise reqEnt = null;
        Organization reqOrg = null;

        //Enterprise respEnt=null;
        Organization respOrg = null;
        for (Enterprise e : enterpriseDirectory.getEnterpriseList()) {
            for (Organization o : e.getOrganizationDirectory().getOrganizationList()) {
                if (o.equals(reqesting)) {
                    reqOrg = o;
                    reqEnt = e;
                    break;
                }
            }
        }
        for (Enterprise e : enterpriseDirectory.getEnterpriseList()) {
            if (e instanceof StateEnterprise) {
                for (Organization o : e.getOrganizationDirectory().getOrganizationList()) {
                    if (o instanceof CitizenOrganization) {
                        if (((CitizenOrganization) o).getName().equals(reqOrg.getName())) {
                            respOrg = (CitizenOrganization) o;
                            break;
                        }
                    }
                }
            }
        }
        return (CitizenOrganization) respOrg;
    }
}

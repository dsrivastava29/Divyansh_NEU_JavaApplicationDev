/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business.health;

import business.general.Issue;
import business.general.Appointment;
import business.users.UserAccount;
import java.util.ArrayList;

/**
 *
 * @author Divyansh
 */
public class HealthInfo {

    /**
     * A class to store user's health information
     */
    private UserAccount doctor;
    private ArrayList<Appointment> appointments;
    private ArrayList<Issue> issues;
    private VitalSignHistory vitalSignList;
    private PrescriptionHistory prescriptionList;

    /**
     *
     * @return
     */
    public UserAccount getDoctorName() {
        return doctor;
    }

    /**
     *
     * @param doctor
     */
    public void setDoctorName(UserAccount doctor) {
        this.doctor = doctor;
    }

    public Appointment createAppointment() {
        Appointment ap = new Appointment();
        appointments.add(ap);
        return ap;
    }

    /**
     *
     * @return
     */
    public ArrayList<Appointment> getAppointments() {
        return appointments;
    }

    /**
     *
     * @param appointments
     */
    public void setAppointments(ArrayList<Appointment> appointments) {
        this.appointments = appointments;
    }

    /**
     *
     * @return
     */
    public ArrayList<Issue> getIssues() {
        return issues;
    }

    /**
     *
     * @param issues
     */
    public void setIssues(ArrayList<Issue> issues) {
        this.issues = issues;
    }

    /**
     *
     */
    public HealthInfo() {
        vitalSignList = new VitalSignHistory();
        prescriptionList = new PrescriptionHistory();
        appointments = new ArrayList<>();
        issues = new ArrayList<>();
    }

    /**
     *
     * @return
     */
    public VitalSignHistory getVitalSignList() {
        return vitalSignList;
    }

    /**
     *
     * @return
     */
    public PrescriptionHistory getPrescriptionList() {
        return prescriptionList;
    }

    /**
     *
     * @param prescriptionList
     */
    public void setPrescriptionList(PrescriptionHistory prescriptionList) {
        this.prescriptionList = prescriptionList;
    }

    /**
     *
     * @param vitalSignList
     */
    public void setVitalSignList(VitalSignHistory vitalSignList) {
        this.vitalSignList = vitalSignList;
    }

}

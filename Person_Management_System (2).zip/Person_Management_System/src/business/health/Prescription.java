/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business.health;

import java.awt.image.BufferedImage;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author Divyansh
 */
public class Prescription {

    /**
     * Store prescriptions
     */
    private static int count = 0;

    /**
     *
     * @return
     */
    public static int getCount() {
        return count;
    }

    /**
     *
     * @return
     */
    public String getId() {
        return id;
    }
    private String doctorName;
    private String id;
    private Date prescriptionDate;
    private String picture_loc;
    private ArrayList<UnitDrug> drugList;

    /**
     *
     * @param userName
     */
    public Prescription(String userName) {
        id = userName + count++;
        drugList = new ArrayList<>();

    }

    @Override
    public String toString() {
        return "" + id;
    }

    /**
     *
     * @return
     */
    public String getPicture_loc() {
        return picture_loc;
    }

    /**
     *
     * @param picture_loc
     */
    public void setPicture_loc(String picture_loc) {
        this.picture_loc = picture_loc;
    }

    /**
     *
     * @return
     */
    public UnitDrug addNewDrug() {
        System.out.println("nd");
        UnitDrug ud = new UnitDrug();
        drugList.add(ud);
        return ud;
    }

    /**
     *
     * @return
     */
    public String getDoctorName() {
        return doctorName;
    }

    /**
     *
     * @param doctorName
     */
    public void setDoctorName(String doctorName) {
        this.doctorName = doctorName;
    }

    /**
     *
     * @return
     */
    public Date getPrescriptionDate() {
        return prescriptionDate;
    }

    /**
     *
     * @param prescriptionDate
     */
    public void setPrescriptionDate(Date prescriptionDate) {
        this.prescriptionDate = prescriptionDate;
    }

    /**
     *
     * @return
     */
    public ArrayList<UnitDrug> getDrugList() {
        return drugList;
    }

    /**
     *
     * @param drugList
     */
    public void setDrugList(ArrayList<UnitDrug> drugList) {
        this.drugList = drugList;
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business.health;

/**
 *
 * @author Divyansh
 */
public class UnitDrug {

    /**
     * Each drug in prescription
     */
    private static int count = 0;
    private String drugName;
    private int quantity;
    private String drugType;
    private int id;

    /**
     *
     */
    public UnitDrug() {
        id = count++;
    }

    /**
     *
     * @return
     */
    public String getDrugName() {
        return drugName;
    }

    /**
     *
     * @param drugName
     */
    public void setDrugName(String drugName) {
        this.drugName = drugName;
    }

    /**
     *
     * @return
     */
    public int getQuantity() {
        return quantity;
    }

    /**
     *
     * @param quantity
     */
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    /**
     *
     * @return
     */
    public String getDrugType() {
        return drugType;
    }

    /**
     *
     * @param drugType
     */
    public void setDrugType(String drugType) {
        this.drugType = drugType;
    }

    @Override
    public String toString() {
        return "" + id;
    }

}

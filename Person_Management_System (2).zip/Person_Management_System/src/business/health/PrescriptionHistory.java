/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business.health;

import java.util.ArrayList;

/**
 *
 * @author Divyansh
 */
public class PrescriptionHistory {

    /**
     * List of all prescriptions
     */
    private ArrayList<Prescription> prescriptions;

    /**
     *
     */
    public PrescriptionHistory() {
        prescriptions = new ArrayList<>();
    }

    /**
     *
     * @return
     */
    public ArrayList<Prescription> getPrescriptions() {
        return prescriptions;
    }

    /**
     *
     * @param userName
     * @return
     */
    public Prescription addNewPres(String userName) {
        Prescription p = new Prescription(userName);
        prescriptions.add(p);
        return p;

    }

    /**
     *
     * @param prescriptions
     */
    public void setPrescriptions(ArrayList<Prescription> prescriptions) {
        this.prescriptions = prescriptions;
    }

}

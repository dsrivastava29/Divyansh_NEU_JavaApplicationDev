/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business.health;

import java.util.ArrayList;

/**
 *
 * @author Divyansh
 */
public class VitalSignHistory {

    /**
     * List of vital signs of user
     */
    private ArrayList<VitalSign> vsList;

    /**
     *
     */
    public VitalSignHistory() {
        this.vsList = new ArrayList<>();
    }

    /**
     *
     * @return
     */
    public ArrayList<VitalSign> getVsList() {
        return vsList;
    }

    /**
     *
     * @param vsList
     */
    public void setVsList(ArrayList<VitalSign> vsList) {
        this.vsList = vsList;
    }

    /**
     *
     * @return
     */
    public VitalSign addVitalSign() {
        VitalSign v = new VitalSign();
        vsList.add(v);
        return v;
    }

    /**
     *
     * @param vitalSign
     */
    public void deleteVitalSign(VitalSign vitalSign) {
        vsList.remove(vitalSign);
    }
}

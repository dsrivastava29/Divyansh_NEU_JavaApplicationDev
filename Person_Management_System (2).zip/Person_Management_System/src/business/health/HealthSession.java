/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business.health;

import java.util.ArrayList;

/**
 *
 * @author Divyansh
 */
public class HealthSession {

    /**
     * Store usres vitals for the session
     */
    private ArrayList<VitalSign> vs;

    /**
     *
     */
    public HealthSession() {
        vs = new ArrayList<>();
    }

    /**
     *
     * @return
     */
    public ArrayList<VitalSign> getVs() {
        return vs;
    }

    /**
     *
     * @param vs
     */
    public void setVs(ArrayList<VitalSign> vs) {
        this.vs = vs;
    }

}

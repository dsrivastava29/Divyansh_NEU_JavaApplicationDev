/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business.health;

import java.util.Date;

/**
 *
 * @author Divyansh
 */
public class VitalSign {

    /**
     * Users basic vital signs
     */
    private float respRate;
    private float heartRate;
    private float bloodPressure;
    private float weight;
    private Date captureTime;

    /**
     *
     * @return
     */
    public float getRespRate() {
        return respRate;
    }

    /**
     *
     * @param respRate
     */
    public void setRespRate(float respRate) {
        this.respRate = respRate;
    }

    /**
     *
     * @return
     */
    public float getHeartRate() {
        return heartRate;
    }

    /**
     *
     * @param heartRate
     */
    public void setHeartRate(float heartRate) {
        this.heartRate = heartRate;
    }

    /**
     *
     * @return
     */
    public float getBloodPressure() {
        return bloodPressure;
    }

    /**
     *
     * @param bloodPressure
     */
    public void setBloodPressure(float bloodPressure) {
        this.bloodPressure = bloodPressure;
    }

    /**
     *
     * @return
     */
    public float getWeight() {
        return weight;
    }

    /**
     *
     * @param weight
     */
    public void setWeight(float weight) {
        this.weight = weight;
    }

    /**
     *
     * @return
     */
    public Date getCaptureTime() {
        return captureTime;
    }

    /**
     *
     * @param captureTime
     */
    public void setCaptureTime(Date captureTime) {
        this.captureTime = captureTime;
    }

    @Override
    public String toString() {
        return captureTime.toString();
    }

}

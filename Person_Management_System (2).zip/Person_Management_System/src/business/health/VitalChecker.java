/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business.health;

import business.personUnit.BasicInfo;
import constants.Constants;
import java.util.Date;
import java.util.Random;

/**
 *
 * @author Divyansh
 */
public class VitalChecker {

    /**
     * class to take vitals from user
     *
     * @param today
     * @param basicInfo
     * @return
     */
    public static float getRandomResp(Date today, BasicInfo basicInfo) {
        Random r = new Random();
        float min = 0.0f, max = 0.0f;

        switch (getAgeGroup(today, basicInfo)) {
            case 1:
                min = 20;
                max = 30;
                break;
            case 2:
                min = 20;
                max = 30;
                break;

            case 3:
                min = 20;
                max = 30;
                break;

            case 4:
                min = 12;
                max = 20;
                break;
        }
        float x = r.nextFloat();
        x = x * (max - min);
        x += min;
        return x;
    }

    /**
     *
     * @param today
     * @param basicInfo
     * @return
     */
    public static float getRandomHrt(Date today, BasicInfo basicInfo) {
        Random r = new Random();
        float min = 0.0f, max = 0.0f;
        switch (getAgeGroup(today, basicInfo)) {
            case 1:
                min = 80;
                max = 130;
                break;
            case 2:
                min = 80;
                max = 120;
                break;

            case 3:
                min = 70;
                max = 110;
                break;

            case 4:
                min = 55;
                max = 105;
                break;
        }
        float x = r.nextFloat();
        x = x * (max - min);
        x += min;
        return x;
    }

    /**
     *
     * @param today
     * @param basicInfo
     * @return
     */
    public static float getRandomBp(Date today, BasicInfo basicInfo) {
        Random r = new Random();
        float min = 0.0f, max = 0.0f;
        switch (getAgeGroup(today, basicInfo)) {
            case 1:
                min = 80;
                max = 110;
                break;
            case 2:
                min = 80;
                max = 110;
                break;
            case 3:
                min = 80;
                max = 110;
                break;
            case 4:
                min = 110;
                max = 120;
                break;
        }
        float x = r.nextFloat();
        x = x * (max - min);
        x += min;
        return x;
    }

    /**
     *
     * @param today
     * @param basicInfo
     * @return
     */
    public static float getRandomWt(Date today, BasicInfo basicInfo) {
        Random r = new Random();
        float min = 0.0f, max = 0.0f;
        switch (getAgeGroup(today, basicInfo)) {
            case 1:
                min = 22;
                max = 31;
                break;
            case 2:
                min = 31;
                max = 40;
                break;

            case 3:
                min = 41;
                max = 92;
                break;

            case 4:
                min = 93;
                max = 110;
                break;
            case -1:
                min = 00;
                max = 00;
                return 0.0f;
        }
        float x = r.nextFloat();
        x = x * (max - min);
        x += min;
        return x;
    }

    private static int getAgeGroup(Date now, BasicInfo basicInfo) {
        long timeDiff = 0;
        int ageGroup = 0;
        if (basicInfo.getDob() != null) {
            timeDiff = now.getTime() - basicInfo.getDob().getTime();
            int captureAge = (int) (timeDiff / (365L * 24 * 60 * 60 * 1000));
            System.out.println("age for " + captureAge);

            if (captureAge >= 0 && captureAge <= 3) {
                ageGroup = 1;
            }
            if (captureAge >= 4 && captureAge <= 5) {
                ageGroup = 2;
            }
            if (captureAge >= 6 && captureAge <= 12) {
                ageGroup = 3;
            }
            if (captureAge >= 13) {
                ageGroup = 4;
            }
        } else {
            ageGroup = -1;
        }
        return ageGroup;
    }

    /**
     *
     * @param vs
     * @param basicInfo
     * @return
     */
    public static String getStatus(VitalSign vs, BasicInfo basicInfo) {

        float respRate = vs.getRespRate();
        float hrtRate = vs.getHeartRate();
        float bp = vs.getBloodPressure();
        float wt = vs.getWeight();
        switch (getAgeGroup(vs.getCaptureTime(), basicInfo)) {
            case 1:
                if (respRate >= 20 && respRate <= 30 && hrtRate >= 80 && hrtRate <= 130 && bp >= 80 && bp <= 110 && wt >= 22 && wt <= 31) {
                    return Constants.NORMAL;
                } else {
                    return Constants.ABNORMAL;
                }

            case 2:
                if (respRate >= 20 && respRate <= 30 && hrtRate >= 80 && hrtRate <= 120 && bp >= 80 && bp <= 110 && wt >= 31 && wt <= 40) {
                    return Constants.NORMAL;
                } else {
                    return Constants.ABNORMAL;
                }
            case 3:
                if (respRate >= 20 && respRate <= 30 && hrtRate >= 70 && hrtRate <= 110 && bp >= 80 && bp <= 120 && wt >= 41 && wt <= 92) {
                    return Constants.NORMAL;
                } else {
                    return Constants.ABNORMAL;
                }
            case 4:
                if (respRate >= 12 && respRate <= 20 && hrtRate >= 55 && hrtRate <= 105 && bp >= 110 && bp <= 120 && wt >= 110) {
                    return Constants.NORMAL;
                } else {
                    return Constants.ABNORMAL;
                }

        }
        return "No Status";
    }
}

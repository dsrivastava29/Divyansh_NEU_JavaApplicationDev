/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business.workque;

import business.family.FamilyInfo;
import business.users.UserAccount;
import constants.Constants;

/**
 * Request to add the family in a city
 *
 * @author Divyansh
 */
public class FamilyCreationWorkRequest extends WorkRequest {

    private String stateName;
    private String cityName;
    private String familyId;

    /**
     *
     * @param family
     * @param currentUser
     */
    public FamilyCreationWorkRequest(FamilyInfo family, UserAccount currentUser) {
        super(currentUser.getMyPerson().getBasicInfo().getCity() + Constants.FamilyCreationWorkRequest);
        super.setSender(currentUser);
        super.setRequestType(Constants.FamilyCreationWorkRequest);
    }

    /**
     *
     * @return
     */
    public String getFamilyId() {
        return familyId;
    }

    /**
     *
     * @param familyId
     */
    public void setFamilyId(String familyId) {
        this.familyId = familyId;
    }

    /**
     *
     * @return
     */
    public String getStateName() {
        return stateName;
    }

    /**
     *
     * @param stateName
     */
    public void setStateName(String stateName) {
        this.stateName = stateName;
    }

    /**
     *
     * @return
     */
    public String getCityName() {
        return cityName;
    }

    /**
     *
     * @param cityName
     */
    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

}

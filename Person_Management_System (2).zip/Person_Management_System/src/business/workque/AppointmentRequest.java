/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business.workque;

import business.general.Appointment;
import constants.Constants;

/**
 *
 * @author Divyansh
 */
public class AppointmentRequest extends WorkRequest {

    public AppointmentRequest(String name) {
        super(name + Constants.AppointmentWorkRequest);
        super.setRequestType(Constants.AppointmentWorkRequest);
        myAppointment=new Appointment();
    }

    private Appointment myAppointment;

    public Appointment getMyAppointment() {
        return myAppointment;
    }

    public void setMyAppointment(Appointment myAppointment) {
        this.myAppointment = myAppointment;
    }

}

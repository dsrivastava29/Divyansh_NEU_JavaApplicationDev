/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business.workque;

import constants.Constants;

/**
 * While user registers, if admin has not created the state, state creation
 * request is sent. User will be assigned as a citizen once his request is
 * approved
 *
 * @author Divyansh
 */
public class StateCreationWorkRequest extends WorkRequest {

    private String networkName;
    private String stateName;
    private String cityName;

    /**
     *
     * @param name
     */
    public StateCreationWorkRequest(String name) {
        super(name + Constants.StateCreationWorkRequest);
        super.setRequestType(Constants.StateCreationWorkRequest);
    }

    /**
     *
     * @return
     */
    public String getNetworkName() {
        return networkName;
    }

    /**
     *
     * @param networkName
     */
    public void setNetworkName(String networkName) {
        this.networkName = networkName;
    }

    /**
     *
     * @return
     */
    public String getStateName() {
        return stateName;
    }

    /**
     *
     * @param stateName
     */
    public void setStateName(String stateName) {
        this.stateName = stateName;
    }

    /**
     *
     * @return
     */
    public String getCityName() {
        return cityName;
    }

    /**
     *
     * @param cityName
     */
    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

}

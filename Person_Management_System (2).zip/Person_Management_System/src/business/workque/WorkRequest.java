/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business.workque;

import business.users.UserAccount;
import java.util.Calendar;
import java.util.Date;

/**
 * A abstract work request to get access between different users and communicate
 *
 * @author Divyansh
 */
public abstract class WorkRequest {

    private String id;
    private String message;
    private UserAccount sender;
    private UserAccount receiver;
    private String status;
    private Date requestDate;
    private Date resolveDate;
    private String requestType;
    public static int count = 0;
    

    /**
     *
     * @return
     */
    public String getRequestType() {
        return requestType;
    }

    /**
     *
     * @param requestType
     */
    public void setRequestType(String requestType) {
        this.requestType = requestType;
    }

    @Override
    public String toString() {
        return id;
    }

    /**
     *
     * @param name
     */
    public WorkRequest(String name) {
        id = name + (count++);
        requestDate = Calendar.getInstance().getTime();
    }

    /**
     *
     * @return
     */
    public String getId() {
        return id;
    }

    /**
     *
     * @param id
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     *
     * @return
     */
    public String getMessage() {
        return this.message;
    }

    /**
     *
     * @param message
     */
    public void setMessage(String message) {
        this.message = message;
    }

    /**
     *
     * @return
     */
    public UserAccount getSender() {
        return this.sender;
    }

    /**
     *
     * @param sender
     */
    public void setSender(UserAccount sender) {
        this.sender = sender;
    }

    /**
     *
     * @return
     */
    public UserAccount getReceiver() {
        return this.receiver;
    }

    /**
     *
     * @param receiver
     */
    public void setReceiver(UserAccount receiver) {
        this.receiver = receiver;
    }

    /**
     *
     * @return
     */
    public String getStatus() {
        return this.status;
    }

    /**
     *
     * @param status
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     *
     * @return
     */
    public Date getRequestDate() {
        return this.requestDate;
    }

    /**
     *
     * @param requestDate
     */
    public void setRequestDate(Date requestDate) {
        this.requestDate = requestDate;
    }

    /**
     *
     * @return
     */
    public Date getResolveDate() {
        return this.resolveDate;
    }

    /**
     *
     * @param resolveDate
     */
    public void setResolveDate(Date resolveDate) {
        this.resolveDate = resolveDate;
    }
}

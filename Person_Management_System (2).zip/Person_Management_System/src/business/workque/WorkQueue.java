/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business.workque;

import java.util.ArrayList;

/**
 * List of worklists for every enterprise and organization
 *
 * @author Divyansh
 */
public class WorkQueue {

    private ArrayList<WorkRequest> workList;

    /**
     *
     */
    public WorkQueue() {
        if(workList!=null){
            WorkRequest.count+=workList.size();
        }
        workList = new ArrayList<>();
    }

    /**
     *
     * @return
     */
    public ArrayList<WorkRequest> getWorkList() {
        return workList;
    }

    /**
     *
     * @param workList
     */
    public void setWorkList(ArrayList<WorkRequest> workList) {
        this.workList = workList;
    }

}

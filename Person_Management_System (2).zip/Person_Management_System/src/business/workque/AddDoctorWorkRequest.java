/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business.workque;

import business.users.UserAccount;
import constants.Constants;

/**
 * Work request dedicated to adding your personal health manager Doctor
 *
 * @author Divyansh
 */
public class AddDoctorWorkRequest extends WorkRequest {

    public AddDoctorWorkRequest(String name) {
        super(name + Constants.AddHealthManagerWorkRequest);
        super.setRequestType(Constants.AddHealthManagerWorkRequest);
    }

    UserAccount previousDoc;

    /**
     *
     * @return
     */
    public UserAccount getPreviousDoc() {
        return previousDoc;
    }

    /**
     *
     * @param previousDoc
     */
    public void setPreviousDoc(UserAccount previousDoc) {
        this.previousDoc = previousDoc;
    }

}

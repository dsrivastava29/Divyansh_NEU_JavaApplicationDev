/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business.workque;

import constants.Constants;

/**
 * USer adds his role as a doctor adn asks administrator to give him doctors
 * features
 *
 * @author Divyansh
 */
public class CreateDoctorRoleWorkRequest extends WorkRequest {

    private String referenceUser;
    private String idProof;
    private String state;
    private String city;

    /**
     *
     * @param name
     */
    public CreateDoctorRoleWorkRequest(String name) {
        super(name + Constants.CreateDoctorRoleWorkRequest);
        super.setRequestType(Constants.CreateDoctorRoleWorkRequest);
    }

    /**
     *
     * @return
     */
    public String getReferenceUser() {
        return referenceUser;
    }

    /**
     *
     * @param referenceUser
     */
    public void setReferenceUser(String referenceUser) {
        this.referenceUser = referenceUser;
    }

    /**
     *
     * @return
     */
    public String getIdProof() {
        return idProof;
    }

    /**
     *
     * @param idProof
     */
    public void setIdProof(String idProof) {
        this.idProof = idProof;
    }

    /**
     *
     * @return
     */
    public String getState() {
        return state;
    }

    /**
     *
     * @param state
     */
    public void setState(String state) {
        this.state = state;
    }

    /**
     *
     * @return
     */
    public String getCity() {
        return city;
    }

    /**
     *
     * @param city
     */
    public void setCity(String city) {
        this.city = city;
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business.family;

import business.users.UserAccount;
import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author Divyansh
 */
public class FamilyInfo {

    /**
     * User's family members info
     */
    private ArrayList<UserAccount> myFamily;
    private String familyId;
    private String createdBy;
    private Date creationDate;
    private String requestId;

    /**
     *
     * @return
     */
    public String getCreatedBy() {
        return createdBy;
    }

    /**
     *
     * @param createdBy
     */
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    /**
     *
     * @return
     */
    public Date getCreationDate() {
        return creationDate;
    }

    /**
     *
     * @param creationDate
     */
    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    /**
     *
     * @return
     */
    public String getRequestId() {
        return requestId;
    }

    /**
     *
     * @param requestId
     */
    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    /**
     *
     * @return
     */
    public String getFamilyId() {
        return familyId;
    }

    /**
     *
     * @param familyId
     */
    public void setFamilyId(String familyId) {
        this.familyId = familyId;
    }

    /**
     *
     */
    public FamilyInfo() {
        myFamily = new ArrayList<>();
    }

    @Override
    public String toString() {
        return familyId;
    }

    /**
     *
     * @return
     */
    public ArrayList<UserAccount> getMyFamily() {
        return myFamily;
    }

    /**
     *
     * @param myFamily
     */
    public void setMyFamily(ArrayList<UserAccount> myFamily) {
        this.myFamily = myFamily;
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business.family;

import java.util.ArrayList;

/**
 *
 * @author Divyansh
 */
public class FamilyDirectory {

    private ArrayList<FamilyInfo> families;
    private String name;
    public static int count = 0;

    /**
     *
     * @param name
     */
    public FamilyDirectory(String name) {
        families = new ArrayList<>();
        this.name = name;
    }

    /**
     *
     * @return
     */
    public ArrayList<FamilyInfo> getFamilies() {
        return families;
    }

    /**
     *
     * @param families
     */
    public void setFamilies(ArrayList<FamilyInfo> families) {
        this.families = families;
    }

    /**
     *
     * @return
     */
    public FamilyInfo addMyFamily() {
        FamilyInfo fi = new FamilyInfo();
        fi.setFamilyId(name + count++);
        families.add(fi);
        return fi;
    }

    /**
     *
     * @param fi
     */
    public void addMyFamily(FamilyInfo fi) {
        //FamilyInfo fi = new FamilyInfo();
        fi.setFamilyId(name + count++);
        families.add(fi);
//        /return fi;
    }

    /**
     *
     * @param fam
     */
    public void removeMyFamily(FamilyInfo fam) {
        families.remove(fam);
    }
}

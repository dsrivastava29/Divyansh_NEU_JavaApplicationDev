/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business.general;

import java.util.Date;

/**
 *
 * @author Divyansh
 */
public class Appointment {

    /**
     * Schedule appointment between users
     */
    private String senderNote;
    private Date ApptTime;

    public String getSenderNote() {
        return senderNote;
    }

    public void setSenderNote(String senderNote) {
        this.senderNote = senderNote;
    }

    public Date getRequestedTime() {
        return ApptTime;
    }

    public void setRequestedTime(Date RequestedTime) {
        this.ApptTime = RequestedTime;
    }

}

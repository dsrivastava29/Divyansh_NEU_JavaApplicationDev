/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business.enterprise;

import business.organization.DoctorOrganization;
import business.organization.Organization;
import business.organization.OrganizationDirectory;
import business.roles.HealthAdminRole;
import business.roles.Role;
import java.util.ArrayList;

/**
 *
 * @author Divyansh
 */
public class HealthEnterprise extends Enterprise {

    /**
     * Enterprise dedicated to health related organziation
     *
     * @param name
     */
    public HealthEnterprise(String name) {
        super(name, EnterpriseType.Health);
    }

    /**
     *
     * @return
     */
    @Override
    public ArrayList<Role> getSupportedRole() {
        ArrayList<Role> roles = new ArrayList<>();
        roles.add(new HealthAdminRole());
        return roles;
    }

    /**
     *
     * @param city
     * @return
     */
    public boolean isCityAvailable(String city) {
        OrganizationDirectory od = this.getOrganizationDirectory();
        for (Organization o : od.getOrganizationList()) {
            if (o instanceof DoctorOrganization) {
                System.out.println(o);
                if (((DoctorOrganization) o).getCityName().equals(city)) {
                    return false;
                }
            }
        }
        return true;
    }

}

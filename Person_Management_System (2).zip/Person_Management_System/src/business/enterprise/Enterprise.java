/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business.enterprise;

import business.organization.Organization;
import business.organization.OrganizationDirectory;
import business.roles.CityAdminRole;
import business.roles.DoctorRole;
import business.roles.Role;
import business.roles.StateAdminRole;
import java.util.ArrayList;

/**
 *
 * @author Divyansh
 */
public abstract class Enterprise extends Organization {

    /**
     * A abstract Enterprise which is collection of organizations
     */
    private EnterpriseType enterpriseType;
    private OrganizationDirectory organizationDirectory;
    private boolean isWorking;

    /**
     *
     * @param name
     * @param type
     */
    public Enterprise(String name, EnterpriseType type) {
        super(name);
        this.enterpriseType = type;
        this.organizationDirectory = new OrganizationDirectory();
        isWorking = false;
        // this.roles = new ArrayList();
    }

    public boolean isIsWorking() {
        return isWorking;
    }

    public void setIsWorking(boolean isWorking) {
        this.isWorking = isWorking;
    }

    /**
     *
     * @return
     */
    public EnterpriseType getEnterpriseType() {
        return this.enterpriseType;
    }

    /**
     *
     * @return
     */
    public OrganizationDirectory getOrganizationDirectory() {
        return this.organizationDirectory;
    }

    /**
     *
     * @return
     */
    @Override
    public abstract ArrayList<Role> getSupportedRole();

    /**
     * All available enterprises
     */
    public static enum EnterpriseType {

        /**
         *
         */
        State("State"),
        /**
         *
         */
        Health("Health");
        private String value;

        private EnterpriseType(String value) {
            this.value = value;
        }

        /**
         *
         * @return
         */
        public String getValue() {
            return this.value;
        }

        public String toString() {
            return this.value;
        }
    }

    @Override
    public String toString() {
        return super.getName();
    }

}

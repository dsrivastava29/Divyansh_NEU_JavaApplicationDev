/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business.enterprise;

import business.network.Network;
import business.organization.Organization;
import business.users.UserAccount;
import java.util.ArrayList;

/**
 *
 * @author Divyansh
 */
public class EnterpriseDirectory {

    /**
     * List of all type of enterprises within the network
     */
    private ArrayList<Enterprise> enterpriseList = new ArrayList();

    /**
     *
     * @return
     */
    public ArrayList<Enterprise> getEnterpriseList() {
        return this.enterpriseList;
    }

    /**
     *
     * @param name
     * @param type
     * @return
     */
    public Enterprise createAndAddEnterprise(String name, Enterprise.EnterpriseType type) {
        Enterprise enterprise = null;
        if (type == Enterprise.EnterpriseType.State) {
            enterprise = new StateEnterprise(name);
                        this.enterpriseList.add(enterprise);
        } else if (type == Enterprise.EnterpriseType.Health) {
            enterprise = new HealthEnterprise(name);
           
            this.enterpriseList.add(enterprise);
        }
        return enterprise;
    }

    /**
     *
     * @param user
     * @return
     */
    public Enterprise findUsersEnterprise(UserAccount user) {
        for (Enterprise enter : getEnterpriseList()) {
            if (enter.getOrganizationDirectory().findUsersCitizenOrg(user) != null) {
                return enter;
            }
        }
        return null;
    }

    /**
     *
     * @param name
     * @return
     */
    public Enterprise getStateEnterpriseByName(String name) {
        for (Enterprise e : getEnterpriseList()) {
            if ((e.getName().equals(name)) && (e instanceof StateEnterprise)) {
                return e;
            }
        }
        return null;
    }

    /**
     *
     * @param name
     * @return
     */
    public Enterprise getHealthEnterpriseByName(String name) {
        for (Enterprise e : getEnterpriseList()) {
            if ((e.getName().equals(name)) && (e instanceof HealthEnterprise)) {
                return e;
            }
        }
        return null;
    }
}

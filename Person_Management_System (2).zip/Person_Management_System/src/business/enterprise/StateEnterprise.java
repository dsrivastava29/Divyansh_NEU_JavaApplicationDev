/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business.enterprise;

import business.organization.CitizenOrganization;
import business.organization.Organization;
import business.organization.OrganizationDirectory;
import business.roles.CitizenRole;
import business.roles.CityAdminRole;
import business.roles.DoctorRole;
import business.roles.Role;
import business.roles.StateAdminRole;
import java.util.ArrayList;

/**
 *
 * @author Divyansh
 */
public class StateEnterprise extends Enterprise {

    /**
     * Enterprise to store all city organizations
     *
     * @param name
     */
    public StateEnterprise(String name) {
        super(name, EnterpriseType.State);
    }

    /**
     *
     * @return
     */
    @Override
    public ArrayList<Role> getSupportedRole() {
        {
            ArrayList<Role> roles = new ArrayList<>();
            roles.add(new StateAdminRole());
            return roles;
        }

    }

    /**
     *
     * @param city
     * @return
     */
    public boolean isCityAvailable(String city) {
        OrganizationDirectory od = super.getOrganizationDirectory();
        for (Organization o : od.getOrganizationList()) {
            if (o instanceof CitizenOrganization) {
                if (((CitizenOrganization) o).getName().equals(city)) {
                    return false;
                }
            }
        }
        return true;
    }

}

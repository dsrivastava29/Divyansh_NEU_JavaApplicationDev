/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business.personUnit;

import business.health.HealthInfo;
import business.finance.FinanceInfo;
import business.family.FamilyInfo;
import constants.Constants;

/**
 * Represents a person which has all info like family, health , finance etc.
 *
 * @author Divyansh
 */
public class MyPerson {

    private int personId;
    private BasicInfo basicInfo;
    private FamilyInfo family;
    private HealthInfo healthInfo;
    private FinanceInfo financeInfo;
    private String profilePicture;
    private LifeRoles myRoles;

    /**
     *
     * @return
     */
    public int getPersonId() {
        return personId;
    }

    /**
     *
     * @param personId
     */
    public void setPersonId(int personId) {
        this.personId = personId;
    }

    /**
     *
     * @return
     */
    public String getProfilePicture() {
        return profilePicture;
    }

    /**
     *
     * @param profilePicture
     */
    public void setProfilePicture(String profilePicture) {
        this.profilePicture = profilePicture;
    }

    /**
     *
     * @return
     */
    public BasicInfo getBasicInfo() {
        return basicInfo;
    }

    /**
     *
     * @param basicInfo
     */
    public void setBasicInfo(BasicInfo basicInfo) {
        this.basicInfo = basicInfo;
    }

    /**
     *
     * @return
     */
    public FamilyInfo getFamily() {
        return family;
    }

    /**
     *
     * @param family
     */
    public void setFamily(FamilyInfo family) {
        this.family = family;
    }

    /**
     *
     * @return
     */
    public HealthInfo getHealthInfo() {
        return healthInfo;
    }

    /**
     *
     * @param healthInfo
     */
    public void setHealthInfo(HealthInfo healthInfo) {
        this.healthInfo = healthInfo;
    }

    /**
     *
     * @return
     */
    public FinanceInfo getFinanceInfo() {
        return financeInfo;
    }

    /**
     *
     * @param financeInfo
     */
    public void setFinanceInfo(FinanceInfo financeInfo) {
        this.financeInfo = financeInfo;
    }

    /**
     *
     * @return
     */
    public LifeRoles getMyRoles() {
        return myRoles;
    }

    /**
     *
     * @param myRoles
     */
    public void setMyRoles(LifeRoles myRoles) {
        this.myRoles = myRoles;
    }

    /**
     *
     * @param count
     */
    public MyPerson(int count) {
        personId = count;
        basicInfo = new BasicInfo();
        family = new FamilyInfo();
        healthInfo = new HealthInfo();
        financeInfo = new FinanceInfo();
        myRoles = new LifeRoles();

        profilePicture = Constants.DEF_PICTURE;
    }

}

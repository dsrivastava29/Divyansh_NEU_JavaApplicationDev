/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business.personUnit;

import business.roles.Role;
import java.util.ArrayList;
import java.util.Calendar;

/**
 * All the roles user is playing right now
 *
 * @author Divyansh
 */
public class LifeRoles {

    private ArrayList<Role> lifeRoles;

    /**
     *
     */
    public LifeRoles() {
        lifeRoles = new ArrayList<>();
    }

    /**
     *
     * @param role
     */
    public void addNewRole(Role role) {
        lifeRoles.add(role);
    }

    /**
     *
     * @return
     */
    public ArrayList<Role> getLifeRoles() {
        return lifeRoles;
    }

    /**
     *
     * @param lifeRoles
     */
    public void setLifeRoles(ArrayList<Role> lifeRoles) {
        this.lifeRoles = lifeRoles;
    }

    /**
     *
     * @param r
     * @return
     */
    public Role selectRole(Role r) {
        for (Role role : getLifeRoles()) {
            if (role.equals(r)) {
                return r;
            }
        }
        return null;
    }

    /**
     *
     * @param r
     */
    public boolean addLifeRole(Role r) {
        for (Role prev : this.lifeRoles) {
            if (r.getType().equals(prev.getType())) {
                if (prev.getEndDate() == null) {
                    return false;
                }
                if (prev.getEndDate().before(Calendar.getInstance().getTime())) {
                    this.lifeRoles.add(r);
                    return true;
                } else {
                    return false;
                }
            }
        }
        this.lifeRoles.add(r);
        return true;
    }

}

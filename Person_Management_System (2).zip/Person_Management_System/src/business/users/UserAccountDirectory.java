package business.users;

import business.personUnit.BasicInfo;
import business.roles.Role;
import java.util.ArrayList;

/**
 * List of all users
 *
 * @author Divyansh
 */
public class UserAccountDirectory {

    private ArrayList<UserAccount> userAccountList;

    /**
     *
     * @return
     */
    public ArrayList<UserAccount> getUserAccountList() {
        return this.userAccountList;
    }

    public UserAccountDirectory() {
//        if(userAccountList!=null){
//            UserAccount.count+=userAccountList.size();
//        }
        userAccountList = new ArrayList();
    }

    /**
     *
     * @param username
     * @param password
     * @return
     */
    public UserAccount authenticateUser(String username, String password) {
        for (UserAccount ua : this.userAccountList) {
            System.out.println("----" + ua.getUsername() + "added last " + ua.getPassword() + " " + ua.getMyPerson().getMyRoles().getLifeRoles() + "\n");
            if (!ua.getUsername().equals(username) || !ua.getPassword().equals(password)) {
                continue;
            }
            return ua;
        }
        return null;
    }

    /**
     *
     * @param userName
     * @return
     */
    public boolean isUserAvailable(String userName) {
        for (UserAccount ua : this.userAccountList) {
            if (ua.getUsername().equals(userName)) {
                return false;
            }
        }
        return true;
    }

    /**
     *
     * @param username
     * @param password
     * @param roles
     * @param basic
     * @return
     */
    public UserAccount createUserAccount(String username, String password, ArrayList<Role> roles, BasicInfo basic) {
        if(UserAccount.count==0 && getUserAccountList().size()>0){
            UserAccount.count=getUserAccountList().size();
        }
        UserAccount userAccount = new UserAccount();
        userAccount.setUsername(username);
        userAccount.setPassword(password);
        userAccount.getMyPerson().getMyRoles().setLifeRoles(roles);
        userAccount.getMyPerson().setBasicInfo(basic);
        this.userAccountList.add(userAccount);

        return userAccount;
    }

    /**
     *
     * @param username
     * @return
     */
    public boolean checkIfUsernameIsUnique(String username) {
        for (UserAccount ua : this.userAccountList) {
            if (!ua.getUsername().equals(username)) {
                continue;
            }
            return false;
        }
        return true;
    }

    public void addUserInDirectory(UserAccount ua) {
        userAccountList.add(ua);
    }
}

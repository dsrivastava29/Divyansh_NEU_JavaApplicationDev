package business.users;

import business.health.HealthSession;
import business.network.Network;
import business.personUnit.MyPerson;
import business.workque.WorkQueue;
import business.workque.WorkRequest;
import userInterface.Sms.TwilioTest;

/**
 * Every user of the application is represented by one UserAccount
 *
 * @author Divyansh
 */
public class UserAccount {

    private String username;
    private String password;
    private Network myNetwork;
    private HealthSession healthSession;
    public static int count = 0;
    private MyPerson myPerson;
    private WorkQueue myWorkQueue;

    /**
     *
     */
    public UserAccount() {
        myPerson = new MyPerson(++count);
        myWorkQueue = new WorkQueue();
        healthSession = new HealthSession();
    }

    /**
     *
     * @return
     */
    public HealthSession getHealthSession() {
        return healthSession;
    }

    /**
     *
     * @param healthSession
     */
    public void setHealthSession(HealthSession healthSession) {
        this.healthSession = healthSession;
    }

    /**
     *
     * @return
     */
    public Network getMyNetwork() {
        return myNetwork;
    }

    /**
     *
     * @param myNetwork
     */
    public void setMyNetwork(Network myNetwork) {
        this.myNetwork = myNetwork;
    }

    //private Employee employee;
    /**
     *
     * @return
     */
    public MyPerson getMyPerson() {
        return myPerson;
    }

    /**
     *
     * @return
     */
    public WorkQueue getMyWorkQueue() {
        return myWorkQueue;
    }

    /**
     *
     * @param myWorkQueue
     */
    public void setMyWorkQueue(WorkQueue myWorkQueue) {
        this.myWorkQueue = myWorkQueue;
    }

    /**
     *
     * @param myPerson
     */
    public void setMyPerson(MyPerson myPerson) {
        this.myPerson = myPerson;
    }

    /**
     *
     * @return
     */
    public String getUsername() {
        return username;
    }

    /**
     *
     * @param username
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     *
     * @return
     */
    public String getPassword() {
        return password;
    }

    /**
     *
     * @param password
     */
    public void setPassword(String password) {
        this.password = password;
    }
    

    public String toString() {
        return this.username;
    }
}

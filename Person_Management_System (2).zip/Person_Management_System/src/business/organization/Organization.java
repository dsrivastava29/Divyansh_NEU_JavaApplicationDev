/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business.organization;

import business.roles.Role;
import business.users.UserAccountDirectory;
import business.workque.WorkQueue;
import constants.Constants;
import java.util.ArrayList;

/**
 *
 * @author Divyansh
 */
public abstract class Organization {

    /**
     * An abstract organization which defines basic rules for every organization
     */
    private String name;
    private WorkQueue workQueue;
    private Type type;
    private UserAccountDirectory userAccountDirectory;

    public Type getType() {
        return type;
    }

    public void setType(Type type) {
        this.type = type;
    }

    /**
     *
     * @param name
     */
    public Organization(String name) {
        this.name = name;
        userAccountDirectory = new UserAccountDirectory();
        workQueue = new WorkQueue();
    }

    /**
     *
     * @return
     */
    public String getName() {
        return name;
    }

    /**
     *
     * @return
     */
    public WorkQueue getWorkQueue() {
        return workQueue;
    }

    /**
     *
     * @param workQueue
     */
    public void setWorkQueue(WorkQueue workQueue) {
        this.workQueue = workQueue;
    }

    /**
     *
     * @param name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     *
     * @return
     */
    public UserAccountDirectory getUserAccountDirectory() {
        return userAccountDirectory;
    }

    /**
     *
     * @param userAccountDirectory
     */
    public void setUserAccountDirectory(UserAccountDirectory userAccountDirectory) {
        this.userAccountDirectory = userAccountDirectory;
    }

    /**
     *
     * @return
     */
    public abstract ArrayList<Role> getSupportedRole();

    /**
     *
     */
    public enum Type {

        /**
         *
         */
        Citizen(Constants.Citizen) {
            //@Override
            public Organization createOrganization() {
                return new CitizenOrganization();
            }
        },
        /**
         *
         */
        Doctor(Constants.Doctor) {

            @Override
            protected Organization createOrganization() {
                return new DoctorOrganization();
            }

        };
        private String value;

        private Type(String value) {
            this.value = value;
        }

        /**
         *
         * @return
         */
        public String getValue() {
            return value;
        }

        /**
         *
         * @param t
         * @return
         */
        public Organization createOrganization(Type t) {
            return t.createOrganization();
        }

        /**
         *
         * @return
         */
        protected abstract Organization createOrganization();

    }

    @Override
    public String toString() {
        return name;
    }

}

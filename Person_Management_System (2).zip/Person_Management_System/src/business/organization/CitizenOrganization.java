/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business.organization;

import business.enterprise.Enterprise;
import business.family.FamilyDirectory;
import business.network.Network;
import business.roles.CitizenRole;
import business.roles.Role;
import business.users.UserAccount;
import java.util.ArrayList;

/**
 *
 * @author Divyansh
 */
public class CitizenOrganization extends Organization {

    /**
     * Organization dedicated to every user who lives in the city
     */
    private Network network;
    private Enterprise enterprise;
    private FamilyDirectory familyDirectory;

    /**
     *
     * @return
     */
    public Network getNetwork() {
        return network;
    }

    /**
     *
     * @param network
     */
    public void setNetwork(Network network) {
        this.network = network;
    }

    /**
     *
     * @return
     */
    public FamilyDirectory getFamilyDirectory() {
        return familyDirectory;
    }

    /**
     *
     * @param familyDirectory
     */
    public void setFamilyDirectory(FamilyDirectory familyDirectory) {
        this.familyDirectory = familyDirectory;
    }

    /**
     *
     */
    public CitizenOrganization() {
        super(Type.Citizen.getValue());
        familyDirectory = new FamilyDirectory(super.getName());
    }

    /**
     *
     * @return
     */
    public Network getNetworkName() {
        return network;
    }

    /**
     *
     * @param networkName
     */
    public void setNetworkName(Network networkName) {
        this.network = networkName;
    }

    /**
     *
     * @return
     */
    public Enterprise getEnterprise() {
        return enterprise;
    }

    /**
     *
     * @param enterprise
     */
    public void setEnterprise(Enterprise enterprise) {
        this.enterprise = enterprise;
    }

    /**
     *
     * @param userName
     * @return
     */
    public UserAccount findCitizen(String userName) {
        for (UserAccount ua : getUserAccountDirectory().getUserAccountList()) {
            System.out.println("Find citizen" + ua.getUsername() + "users " + getUserAccountDirectory().getUserAccountList().size());
            if (ua.getUsername().equals(userName)) {
                return ua;
            }
        }
        return null;
    }

    /**
     *
     * @return
     */
    @Override
    public ArrayList<Role> getSupportedRole() {
        ArrayList<Role> roles = new ArrayList<>();
        roles.add(new CitizenRole());
        return roles;
    }

}

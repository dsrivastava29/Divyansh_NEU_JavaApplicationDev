/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business.organization;

import business.users.UserAccount;
import java.util.ArrayList;

/**
 *
 *
 * @author Divyansh
 */
public class OrganizationDirectory {

    /**
     * List of organizations in an enterprize
     */
    private ArrayList<Organization> organizationList;

    /**
     *
     * @return
     */
    public ArrayList<Organization> getOrganizationList() {
        return this.organizationList;
    }

    /**
     *
     */
    public OrganizationDirectory() {
        organizationList = new ArrayList<>();
    }

    /**
     *
     * @param type
     * @return
     */
    public Organization createOrganization(Organization.Type type) {
        Organization organization = null;
        if (type.getValue().equals(Organization.Type.Citizen.getValue())) {
            organization = new CitizenOrganization();
            this.organizationList.add(organization);
        } else if (type.getValue().equals(Organization.Type.Doctor.getValue())) {
            organization = new DoctorOrganization();
            this.organizationList.add(organization);
        }
        return organization;
    }

    /**
     *
     * @param user
     * @return
     */
    public CitizenOrganization findUsersCitizenOrg(UserAccount user) {
        for (Organization o : getOrganizationList()) {
            if (o instanceof CitizenOrganization) {
                for (UserAccount u : ((CitizenOrganization) o).getUserAccountDirectory().getUserAccountList()) {
                    if (u.equals(user)) {
                        return (CitizenOrganization) o;
                    }
                }
            }
        }
        return null;
    }

    /**
     *
     * @return
     */
    public int getCitizenCount() {
        int count = 0;
        for (Organization o : getOrganizationList()) {
            if (o instanceof CitizenOrganization) {
                count += ((CitizenOrganization) o).getUserAccountDirectory().getUserAccountList().size();
            }
        }
        return count;
    }
}

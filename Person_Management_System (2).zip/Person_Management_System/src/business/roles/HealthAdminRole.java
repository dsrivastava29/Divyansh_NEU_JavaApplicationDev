/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business.roles;

import business.EcoSystem;
import business.enterprise.Enterprise;
import business.organization.Organization;
import business.users.UserAccount;
import javax.swing.JPanel;
import userInterface.healthEnt.HealthAdminJPanel;

/**
 * Health enterprise level administrator
 *
 * @author Divyansh
 */
public class HealthAdminRole extends Role {

    public HealthAdminRole() {
        super(RoleType.HealthAdmin);
    }

    /**
     *
     * @param userProcessContainer
     * @param account
     * @param organization
     * @param enterprise
     * @param business
     * @return
     */
    @Override
    public JPanel createWorkArea(JPanel userProcessContainer, UserAccount account, Organization organization, Enterprise enterprise, EcoSystem business) {
        return new HealthAdminJPanel(userProcessContainer, account, enterprise, business);
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business.roles;

import business.EcoSystem;
import business.enterprise.Enterprise;
import business.organization.Organization;
import business.roles.Role;
import business.users.UserAccount;
import javax.swing.JPanel;
import userInterface.states.StateAdminJPanel;

/**
 * State level administrator
 *
 * @author Divyansh
 */
public class StateAdminRole extends Role {

    /**
     *
     */
    public StateAdminRole() {
        super(RoleType.StateAdmin);
    }

    /**
     *
     * @param userProcessContainer
     * @param account
     * @param organization
     * @param enterprise
     * @param business
     * @return
     */
    @Override
    public JPanel createWorkArea(JPanel userProcessContainer, UserAccount account, Organization organization, Enterprise enterprise, EcoSystem business) {
        return new StateAdminJPanel(userProcessContainer, account, enterprise);
    }

}

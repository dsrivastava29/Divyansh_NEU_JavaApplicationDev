/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business.roles;

import business.EcoSystem;
import business.enterprise.Enterprise;
import business.organization.Organization;
import business.users.UserAccount;
import javax.swing.JPanel;
import constants.Constants;
import java.util.Calendar;
import java.util.Date;

/**
 * Abstract Role which defines basic feature of a role
 *
 * @author Divyansh
 */
public abstract class Role {

    private RoleType type;

    public Role(RoleType type) {
        this();
        this.type = type;

    }

    /**
     *
     */
    public enum RoleType {

        /**
         *
         */
        SystemAdmin(Constants.SysAdmin),
        /**
         *
         */
        CityAdmin(Constants.CityAdmin),
        /**
         *
         */
        StateAdmin(Constants.StateAdmin),
        /**
         *
         */
        HealthAdmin(Constants.HealthAdmin),
        /**
         *
         */
        CountryAdmin(Constants.CountryAdmin),
        /**
         *
         */
        Citizen(Constants.Citizen),
        /**
         *
         */
        Doctor(Constants.Doctor),
        /**
         *
         */
        Police(Constants.Police),
        /**
         *
         */
        Accountant(Constants.Accountant),
        /**
         *
         */
        Employer(Constants.Employer),
        /**
         *
         */
        Employee(Constants.Employee);

        private String value;

        private RoleType(String value) {
            this.value = value;
        }

        /**
         *
         * @return
         */
        public String getValue() {
            return value;
        }

        @Override
        public String toString() {
            return value;
        }
    }
    private Date startDate;
    private Date endDate;

    /**
     *
     * @return
     */
    public Date getStartDate() {
        return startDate;
    }

    /**
     *
     * @param startDate
     */
    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    /**
     *
     * @return
     */
    public Date getEndDate() {
        return endDate;
    }

    /**
     *
     * @param endDate
     */
    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    @Override
    public String toString() {
        return getType().getValue();
    }

    /**
     *
     * @param userProcessContainer
     * @param account
     * @param organization
     * @param enterprise
     * @param business
     * @return
     */
    public abstract JPanel createWorkArea(JPanel userProcessContainer, UserAccount account, Organization organization, Enterprise enterprise, EcoSystem business);

    public RoleType getType() {
        return type;
    }

    public Role() {
        startDate = Calendar.getInstance().getTime();
    }

    public void setType(RoleType type) {
        this.type = type;
    }

}

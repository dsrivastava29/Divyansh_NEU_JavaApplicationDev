/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business.roles;

import business.EcoSystem;
import business.enterprise.Enterprise;
import business.organization.Organization;
import business.roles.Role;
import business.users.UserAccount;
import javax.swing.JPanel;

/**
 * By default every user is a citizen once registered. In case there is any
 * unavailable information, user becomes citizen once approved by admin
 *
 * @author Divyansh
 */
public class CitizenRole extends Role {

    /**
     *
     */
    public CitizenRole() {
        super(RoleType.Citizen);
    }

    /**
     *
     * @param userProcessContainer
     * @param account
     * @param organization
     * @param enterprise
     * @param business
     * @return
     */
    @Override
    public JPanel createWorkArea(JPanel userProcessContainer, UserAccount account, Organization organization, Enterprise enterprise, EcoSystem business) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controls;

import business.personUnit.BasicInfo;
import constants.Constants;
import java.util.ArrayList;
import java.util.Locale;

/**
 * Some helper functions of application to interact with other data outside
 *
 * @author Divyansh
 */
public class DataHelper {

    /**
     *
     * @param country
     * @return
     */
    public static ArrayList<String> getStatesInCountry(String country) {
        ArrayList<String> states = new ArrayList<>();
        if (country.equals(Constants.IN)) {
            states.add(Constants.INDIA_KL);
            states.add(Constants.INDIA_KT);
        }
        if (country.equals(Constants.US)) {
            states.add(Constants.US_MA);
            states.add(Constants.US_CL);
            states.add(Constants.US_FL);
            states.add(Constants.US_NY);
        }

        return states;

    }

    /**
     *
     * @param state
     * @return
     */
    public static ArrayList<String> getCitiesInSate(String state) {
        ArrayList<String> cities = new ArrayList<>();
        if (state.equals(Constants.US_MA)) {
            cities.add(Constants.US_MA_Boston);
            cities.add(Constants.US_MA_Camb);
            cities.add(Constants.US_MA_Quincy);
            cities.add(Constants.US_MA_Salem);
        }
        if (state.equals(Constants.US_CL)) {
            cities.add(Constants.US_CL_LA);
            cities.add(Constants.US_CL_SJ);
        }
        if (state.equals(Constants.US_FL)) {
            cities.add(Constants.US_FL_MM);
            cities.add(Constants.US_FL_TP);
        }
        if (state.equals(Constants.US_NY)) {
            cities.add(Constants.US_NY_ALB);
            cities.add(Constants.US_NY_ROCH);
        }
        if (state.equals(Constants.INDIA_KL)) {
            cities.add(Constants.INDIA_KL_KM);
            cities.add(Constants.INDIA_KL_TD);
        }
        if (state.equals(Constants.INDIA_KT)) {
            cities.add(Constants.INDIA_KT_BG);
            cities.add(Constants.INDIA_KT_MY);
        }
        return cities;

    }

}

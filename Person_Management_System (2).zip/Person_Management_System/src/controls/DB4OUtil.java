package controls;

import business.ConfigureSystem;
import business.EcoSystem;
import com.db4o.Db4oEmbedded;
import com.db4o.EmbeddedObjectContainer;
import com.db4o.ObjectContainer;
import com.db4o.ObjectSet;
import com.db4o.config.ConfigurationItem;
import com.db4o.config.EmbeddedConfiguration;
import com.db4o.ta.TransparentPersistenceSupport;

/**
 * DBO4 related methods
 *
 * @author Divyansh
 */
public class DB4OUtil {

    private static final String FILENAME = System.getProperty("user.dir") + "\\DataBank.db4o";
    private static DB4OUtil dB4OUtil;

    /**
     *
     * @return
     */
    public static synchronized DB4OUtil getInstance() {
        if (dB4OUtil == null) {
            dB4OUtil = new DB4OUtil();
        }
        return dB4OUtil;
    }

    /**
     *
     * @param conn
     */
    protected static synchronized void shutdown(ObjectContainer conn) {
        if (conn != null) {
            conn.close();
        }
    }

    private ObjectContainer createConnection() {
        try {
            EmbeddedConfiguration config = Db4oEmbedded.newConfiguration();
            config.common().add((ConfigurationItem) new TransparentPersistenceSupport());
            config.common().activationDepth(Integer.MAX_VALUE);
            config.common().updateDepth(Integer.MAX_VALUE);
            config.common().objectClass((Object) EcoSystem.class).cascadeOnUpdate(true);
            EmbeddedObjectContainer db = Db4oEmbedded.openFile((EmbeddedConfiguration) config, (String) FILENAME);
            return db;
        } catch (Exception ex) {
            System.out.print(ex.getMessage());
            System.out.println("DB4O create connection error");
            return null;
        }
    }

    /**
     *
     * @param system
     */
    public synchronized void storeSystem(EcoSystem system) {
        try {
            ObjectContainer conn = this.createConnection();
            conn.store((Object) system);
            conn.commit();
            conn.close();
        } catch (Exception e) {
            System.out.println("DB4 commit error\n Cant store the system object");
        }

    }

    /**
     *
     * @return
     */
    public EcoSystem retrieveSystem() {
        EcoSystem system = null;
        try {
            ObjectContainer conn = this.createConnection();
            ObjectSet systems = conn.query((Class) EcoSystem.class);
            system = systems.size() == 0 ? ConfigureSystem.configure() : (EcoSystem) systems.get(systems.size() - 1);
            conn.close();
        } catch (Exception e) {
            System.out.println("DB4 commit error\n Cant store the system object");
            return null;
        }
        return system;
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package constants;

/**
 * All constant values used in the application
 *
 * @author Divyansh
 */
public class Constants {
    /*
    Business Constants
     */

    /**
     *
     */
    public static final String SysAdmin = "SystemAdmin";

    /**
     *
     */
    public static final String CityAdmin = "CityAdmin";

    /**
     *
     */
    public static final String StateAdmin = "StateAdmin";

    /**
     *
     */
    public static final String HealthAdmin = "HealthAdmin";

    /**
     *
     */
    public static final String CountryAdmin = "CountryAdmin";

    /**
     *
     */
    public static final String Citizen = "Citizen";

    /**
     *
     */
    public static final String Doctor = "Doctor";

    /**
     *
     */
    public static final String Student = "Student";

    /**
     *
     */
    public static final String Teacher = "Techer";

    /**
     *
     */
    public static final String Police = "Police";

    /**
     *
     */
    public static final String Accountant = "Accountant";

    /**
     *
     */
    public static final String Employer = "Employer";

    /**
     *
     */
    public static final String Employee = "Employee";

    public static final String APPOINTMENTMSG = "Need to schedule the appointment";

    /**
     *
     */
    public static final String PENDING = "Pending";

    /**
     *
     */
    public static final String WORKING = "Working";

    /**
     *
     */
    public static final String TRANFER = "Transfer";

    /**
     *
     */
    public static final String DONE = "Closed";

    /**
     *
     */
    public static final String DECLINE = "Declined";

    //health
    /**
     *
     */
    public static final String NORMAL = "NORMAL";

    /**
     *
     */
    public static final String ABNORMAL = "ABNORMAL";

    /**
     *
     */
    public static final String TITLE_HEALTH = "Health Report";

    /**
     *
     */
    public static final String CHART_RESP = "Health Report";

    /**
     *
     */
    public static final String CHART_BP = "Blood Pressure";

    /**
     *
     */
    public static final String CHART_HRT = "Heart Rate";

    /**
     *
     */
    public static final String CHART_WT = "Weight";

    /**
     *
     */
    public static final String US = "United States";

    /**
     *
     */
    public static final String IN = "India";

    //states
    /**
     *
     */
    public static final String StateCreationWorkRequest = "SCWR";

    /**
     *
     */
    public static final String CreateDoctorRoleWorkRequest = "CDRWR";

    public static final String AppointmentWorkRequest = "APWR";

    public static final String AddHealthManagerWorkRequest = "AHMWR";
    /**
     *
     */
    public static final String FamilyCreationWorkRequest = "FCWR";
    //public static final String CreateDoctorRoleWorkRequest = "SCWR";

    public static final String DoctorApptWorkRequest = "DAWR";
    /**
     *
     */
    public static final String US_MA = "massachusetts";

    /**
     *
     */
    public static final String US_MA_Boston = "Boston";

    /**
     *
     */
    public static final String US_MA_Camb = "Cambridge";

    /**
     *
     */
    public static final String US_MA_Quincy = "Quincy";

    /**
     *
     */
    public static final String US_MA_Salem = "Salem";

    /**
     *
     */
    public static final String US_NY = "NewYork";

    /**
     *
     */
    public static final String US_NY_ALB = "Albany";

    /**
     *
     */
    public static final String US_NY_ROCH = "Rochester";

    /**
     *
     */
    public static final String US_FL = "Florida";

    /**
     *
     */
    public static final String US_FL_MM = "Miami";

    /**
     *
     */
    public static final String US_FL_TP = "Tampa";

    /**
     *
     */
    public static final String US_CL = "california";

    /**
     *
     */
    public static final String US_CL_SJ = "San Jose";

    /**
     *
     */
    public static final String US_CL_LA = "Los Angeles";

    /**
     *
     */
    public static final String INDIA_KT = "Karnataka";

    /**
     *
     */
    public static final String INDIA_KT_BG = "Bangaluru";

    /**
     *
     */
    public static final String INDIA_KT_MY = "Mysuru";

    /**
     *
     */
    public static final String INDIA_KL = "Kerala";

    /**
     *
     */
    public static final String INDIA_KL_TD = "Trivandrum";

    /**
     *
     */
    public static final String INDIA_KL_KM = "Kollam";

    /**
     *
     */
    public static final String COUNTRY_NOT_FOUND = "Country not found";

    public static final String OTHER_ERROR = "Something went wrong";
    /**
     *
     */
    public static final String STATE_NOT_FOUND = "State not found";

    /**
     *
     */
    public static final String SUCCESS = "Success";

    /**
     *
     */
    public static final String USER_NOT_AVAILABLE = "User name not available";

    /*
    UI Constants
     */
    /**
     *
     */
    public static final String ROUTINE_LOC = "/src/routines/";

    /**
     *
     */
    public static final String PICTURE_LOC = "/pictures/";

    /**
     *
     */
    public static final String DEF_PICTURE = "IMGUSERDEF.jpg";

    /**
     *
     */
    public static final String TITLE = "Title";

    /**
     *
     */
    public static final String LOGIN = "Login";

    /**
     *
     */
    public static final String REGISTER = "Register";

    /**
     *
     */
    public static final String HOME = "Home";

    /**
     *
     */
    public static final String CONNECTION = "Connections";

    /**
     *
     */
    public static final String REPORT = "Reports";

    /**
     *
     */
    public static final String INTERFACES = "Meet the world";

    /**
     *
     */
    public static final String SETTING = "Profile/ Settings";

    /**
     *
     */
    public static final String LOGOUT = "Signout";

    /**
     *
     */
    public static final String IMAGE_HOME = "/images/home.png";

    /**
     *
     */
    public static final String IMAGE_CONNECTION = "/images/connections.png";

    /**
     *
     */
    public static final String IMAGE_REPORTS = "/images/reports.png";

    /**
     *
     */
    public static final String IMAGE_INTERFACES = "/images/interfaces.png";

    /**
     *
     */
    public static final String IMAGE_SETTINGS = "/images/settings.png";

    /**
     *
     */
    public static final String IMAGE_LOGOUT = "/images/logout.png";

    /**
     *
     */
    public static final String IMAGE_LOGIN = "/images/logout.png";

    /**
     *
     */
    public static final String IMAGE_REGISTER = "/images/newuser.png";

    /**
     *
     */
    public static final String CLICK_SOUND = "/sounds/click.wav";

    /**
     *
     */
    public static final String HEADLEFT = "Me";

    /**
     *
     */
    public static final String HEADRIGHT = "Myself";

    /**
     *
     */
    public static final String ADDNEW = "Add New";

    /**
     *
     */
    public static final String VIEWCON = "View Family";

    /**
     *
     */
    public static final String IMAGE_ADDNEW = "/images/add.png";

    /**
     *
     */
    public static final String IMAGE_VIEWCONNECTION = "/images/viewfamily.png";

    /**
     *
     */
    public static final String ABOUTNOTE = "Created as AED final project.\n Guide: Prof. Kal Bugrara\n Northeastren University";

}

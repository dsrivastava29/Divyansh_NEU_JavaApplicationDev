/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business.suppliers;

import business.products.ProductCatalog;

/**
 *
 * @author Divyansh
 */
public class Supplier {

    private String SupplierName;
    private int supplierId;
    private ProductCatalog productCatalog;

    public Supplier() {
        productCatalog = new ProductCatalog();
    }

    @Override
    public String toString() {
        return this.SupplierName;
    }

    public ProductCatalog getProductCatalog() {
        return productCatalog;
    }

    public void setProductCatalog(ProductCatalog productCatalog) {
        this.productCatalog = productCatalog;
    }

    public String getSupplierName() {
        return SupplierName;
    }

    public void setSupplierName(String SupplierName) {
        this.SupplierName = SupplierName;
    }

    public int getSupplierId() {
        return supplierId;
    }

    public void setSupplierId(int supplierId) {
        this.supplierId = supplierId;
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business.suppliers;

import java.util.ArrayList;

/**
 *
 * @author Divyansh
 */
public class SupplierCatalog {

    private ArrayList<Supplier> supplierDirectory;

    public SupplierCatalog() {
        supplierDirectory = new ArrayList<>();
    }

    public ArrayList<Supplier> getSupplierDirectory() {
        return supplierDirectory;
    }

    public void setSupplierDirectory(ArrayList<Supplier> supplierDirectory) {
        this.supplierDirectory = supplierDirectory;
    }

    public Supplier addSupplier() {
        Supplier sup = new Supplier();
        supplierDirectory.add(sup);
        return sup;
    }

}

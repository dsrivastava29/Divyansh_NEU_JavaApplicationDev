/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business.users;

import java.util.ArrayList;

/**
 *
 * @author Divyansh
 */
public class AdminDirectory {

    private ArrayList<Admin> adminDir;

    public AdminDirectory() {
        adminDir = new ArrayList<>();
    }

    public ArrayList<Admin> getAdminDir() {
        return adminDir;
    }

    public void setAdminDir(ArrayList<Admin> adminDir) {
        this.adminDir = adminDir;
    }

    public Admin addNewAdmin() {
        Admin newAdmin = new Admin();
        adminDir.add(newAdmin);
        return newAdmin;
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business.stores;

import business.drugs.DrugInventory;

/**
 *
 * @author Divyansh
 */
public class Store {

    private String Location;
    private DrugInventory drugInventory;
    private int storeId;
    public static int count = 1000;
    private String storeDesc;

    @Override
    public String toString() {
        return "" + this.storeId;
    }

    public String getStoreDesc() {
        return storeDesc;
    }

    public void setStoreDesc(String storeDesc) {
        this.storeDesc = storeDesc;
    }

    public Store() {
        storeId = count++;
        drugInventory = new DrugInventory();
    }

    public DrugInventory getDrugInventory() {
        return drugInventory;
    }

    public void setDrugInventory(DrugInventory drugInventory) {
        this.drugInventory = drugInventory;
    }

    public String getLocation() {
        return Location;
    }

    public void setLocation(String Location) {
        this.Location = Location;
    }

    public int getStoreId() {
        return storeId;
    }

    public void setStoreId(int storeId) {
        this.storeId = storeId;
    }

}

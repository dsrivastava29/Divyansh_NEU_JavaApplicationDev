/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business;

import business.drugs.DrugCatalog;
import business.users.AdminDirectory;
import business.stores.StoreDirectory;
import business.suppliers.SupplierCatalog;

/**
 * CVS Main Store
 *
 * @author Divyansh
 */
public class CVSMain {

    private AdminDirectory adminDir;
    private StoreDirectory storeDir;
    private SupplierCatalog suppCat;
    private DrugCatalog drugCat;

    //Master key for the registeration feature
    public static int masterKey = 1111;

    public static String CVSAdmin = "CVS Admin";
    public static String StoreAdmin = "Store Admin";

    public CVSMain() {

        adminDir = new AdminDirectory();
        storeDir = new StoreDirectory();
        suppCat = new SupplierCatalog();
        drugCat = new DrugCatalog();
    }

    public static int getMasterKey() {
        return masterKey;
    }

    public SupplierCatalog getSuppCat() {
        return suppCat;
    }

    public void setSuppCat(SupplierCatalog suppCat) {
        this.suppCat = suppCat;
    }

    public DrugCatalog getDrugCat() {
        return drugCat;
    }

    public void setDrugCat(DrugCatalog drugCat) {
        this.drugCat = drugCat;
    }

    public static void setMasterKey(int masterKey) {
        CVSMain.masterKey = masterKey;
    }

    public AdminDirectory getAdminDir() {
        return adminDir;
    }

    public void setAdminDir(AdminDirectory adminDir) {
        this.adminDir = adminDir;
    }

    public StoreDirectory getStoreDir() {
        return storeDir;
    }

    public void setStoreDir(StoreDirectory storeDir) {
        this.storeDir = storeDir;
    }

}

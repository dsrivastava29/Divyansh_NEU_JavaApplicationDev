/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business.drugs;

/**
 *
 * @author Divyansh
 */
public class DrugItem {

    private Drug drugInfo;
    private String itemId;
    private int quantity;
    private float sellPrice;

    public DrugItem() {
        drugInfo = new Drug();
    }

    @Override
    public String toString() {
        return "" + itemId;
    }

    public Drug getDrugInfo() {
        return drugInfo;
    }

    public void setDrugInfo(Drug drugInfo) {
        this.drugInfo = drugInfo;
    }

    public String getItemId() {
        return itemId;
    }

    public void setItemId(String itemId) {
        this.itemId = itemId;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public float getSellPrice() {
        return sellPrice;
    }

    public void setSellPrice(float sellPrice) {
        this.sellPrice = sellPrice;
    }

}

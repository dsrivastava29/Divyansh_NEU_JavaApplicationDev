/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business.drugs;

import java.util.ArrayList;

/**
 *
 * @author Divyansh
 */
public class DrugCatalog {

    private ArrayList<Drug> drugCatalog;

    public DrugCatalog() {
        drugCatalog = new ArrayList<>();
    }

    public ArrayList<Drug> getDrugCatalog() {
        return drugCatalog;
    }

    public void setDrugCatalog(ArrayList<Drug> drugCatalog) {
        this.drugCatalog = drugCatalog;
    }

    public void addDrugtoCatalog(Drug d) {
        drugCatalog.add(d);
    }

    public Drug addDrug() {
        Drug g = new Drug();
        drugCatalog.add(g);
        return g;
    }

    public void deleteDrugFromCat(Drug d) {
        drugCatalog.remove(d);
    }
}

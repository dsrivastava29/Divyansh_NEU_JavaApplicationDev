/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business.drugs;

/**
 *
 * @author Divyansh
 */
public class Drug {

    private String drugId;
    private String drugName;
    private int SupplierId;
    private String drugType;
    private String dosageInfo;
    private String colour;
    private Boolean isOnlyPres;
    private String category;
    private String drugDesc;
    private String drugWarning;
    private float price;

    @Override
    public String toString() {
        return "" + drugId;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }
    private String manufacturer;

    public Drug() {
        isOnlyPres = false;
    }

    public String getDrugId() {
        return drugId;
    }

    public void setDrugId(String drugId) {
        this.drugId = drugId;
    }

    public String getDrugName() {
        return drugName;
    }

    public void setDrugName(String drugName) {
        this.drugName = drugName;
    }

    public int getSupplierId() {
        return SupplierId;
    }

    public void setSupplierId(int SupplierId) {
        this.SupplierId = SupplierId;
    }

    public String getDrugType() {
        return drugType;
    }

    public void setDrugType(String drugType) {
        this.drugType = drugType;
    }

    public String getDosageInfo() {
        return dosageInfo;
    }

    public void setDosageInfo(String dosageInfo) {
        this.dosageInfo = dosageInfo;
    }

    public String getColour() {
        return colour;
    }

    public void setColour(String colour) {
        this.colour = colour;
    }

    public Boolean getIsOnlyPres() {
        return isOnlyPres;
    }

    public void setIsOnlyPres(Boolean isOnlyPres) {
        this.isOnlyPres = isOnlyPres;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getDrugDesc() {
        return drugDesc;
    }

    public void setDrugDesc(String drugDesc) {
        this.drugDesc = drugDesc;
    }

    public String getDrugWarning() {
        return drugWarning;
    }

    public void setDrugWarning(String drugWarning) {
        this.drugWarning = drugWarning;
    }

}

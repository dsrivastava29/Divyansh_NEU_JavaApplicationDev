/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business.drugs;

import java.util.ArrayList;

/**
 *
 * @author Divyansh
 */
public class DrugInventory {

    private ArrayList<DrugItem> drugItemList;

    public DrugInventory() {
        drugItemList = new ArrayList<>();
    }

    public ArrayList<DrugItem> getDrugItemList() {
        return drugItemList;
    }

    public void setDrugItemList(ArrayList<DrugItem> drugItemList) {
        this.drugItemList = drugItemList;
    }

    public void addDrugtoInventory(DrugItem d) {
        drugItemList.add(d);
    }

    public DrugItem addDrugItem() {
        DrugItem g = new DrugItem();
        drugItemList.add(g);
        return g;
    }

    public void deleteDrugFromInv(DrugItem d) {
        drugItemList.remove(d);
    }

}

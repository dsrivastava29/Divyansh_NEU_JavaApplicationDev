/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package userInterface.others;

import business.products.Product;
import business.suppliers.Supplier;
import business.suppliers.SupplierCatalog;
import java.util.ArrayList;

/**
 *
 * @author Divyansh
 */
public class InitializeSupplierFromFile {

    private SupplierCatalog supplierDir;
    private static int drugID = 1;

    public InitializeSupplierFromFile() {
        this.supplierDir = new SupplierCatalog();
    }

    public SupplierCatalog InitializeSupplierList() {
        Supplier sups[] = setSuppliers();
        ArrayList<Supplier> suppList = new ArrayList<Supplier>();
        for (int i = 0; i < sups.length; i++) {
            suppList.add(sups[i]);
        }
        supplierDir.setSupplierDirectory(suppList);
        initializeSupplierDirectory(supplierDir);
        return supplierDir;
    }

    private static Supplier[] setSuppliers() {
        Supplier[] intialSuppliers = new Supplier[5];
        String supNames[] = constants.SupplierAndProduct.suppNames;
        for (int i = 0; i < supNames.length; i++) {
            intialSuppliers[i] = new Supplier();
            intialSuppliers[i].setSupplierId(i + 1);
            intialSuppliers[i].setSupplierName(supNames[i]);
        }
        return intialSuppliers;
    }

    private static void initializeSupplierDirectory(SupplierCatalog suppDir) {

        int cnt = 0;
        for (Supplier s : suppDir.getSupplierDirectory()) {
            String sName = s.getSupplierName();
            String[][] prodList;
            switch (sName) {
                //Pfizer", "Novartis", "Sanofi", "AstraZeneca", "GlaxoSmithKline
                case "Pfizer":
                    prodList = constants.SupplierAndProduct.Pfizer_ProList;
                    break;
                case "Novartis":
                    prodList = constants.SupplierAndProduct.Novartis_ProList;
                    break;
                case "Sanofi":
                    prodList = constants.SupplierAndProduct.Sanofi_ProList;
                    break;
                case "AstraZeneca":
                    prodList = constants.SupplierAndProduct.AstraZeneca_ProList;
                    break;
                case "GlaxoSmithKline":
                    prodList = constants.SupplierAndProduct.GlaxoSmithKline_ProList;
                    break;
                default:
                    prodList = null;
            }
            if ((prodList != null)) {
                Product p;
                for (int j = 0; j < prodList.length; j++) {
                    String subList[] = prodList[j];

                    p = s.getProductCatalog().addProduct();
                    p.setProductId(drugID++);
                    p.setProductName(subList[0]);
                    p.setPrice(Integer.parseInt(subList[1]));
                    p.setManufacturer(s.getSupplierName());
                }
            }
        }
    }
}

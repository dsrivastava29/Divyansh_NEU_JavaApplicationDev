/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package userInterface.Admin_Store;

import business.drugs.Drug;
import business.drugs.DrugCatalog;
import business.drugs.DrugInventory;
import business.drugs.DrugItem;
import business.products.Product;
import business.stores.Store;
import business.stores.StoreDirectory;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

/**
 * Drug Inventory management
 * @author Divyansh
 */
public class CreateManageDrugInventory extends javax.swing.JPanel {

    /**
     * Creates new form manageStores
     */
    //UI
    JPanel userProcessContainer;
    //Business
    StoreDirectory storeDirectory;
    DrugCatalog drugList;
    DrugInventory mainInventory;
    DrugInventory drugInv;
    Store store;
    String option;

    public CreateManageDrugInventory(JPanel userProcessContainer, DrugCatalog drugCat, Store userStore, StoreDirectory storeDirectory, String option) {
        initComponents();
        this.userProcessContainer = userProcessContainer;
        this.storeDirectory = storeDirectory;
        this.drugList = drugCat;
        this.store = userStore;
        this.option = option;
        addToCatalog.setEnabled(true);
        this.mainInventory = userStore.getDrugInventory();
        try {
            storeNumber.setText(String.valueOf(userStore.getStoreId()));
            drugInv = new DrugInventory();
            //Load drugs
            loadDrugs();
            //setValuesInDrugPanel((Drug) drugCatDrugList.getItemAt(0));
            configureDrugListCombo();
            String supName = (String) drugCatDrugList.getItemAt(0);
            loadDrug(supName);
            if (mainInventory.getDrugItemList().size() > 0) {
                //populateTable();
                copyToLocalInventory();
            }
            refreshTable();
            loadDrug(drugInv.getDrugItemList().get(0).getDrugInfo().getDrugName());
            //set action button name
            if (option.equals("CREATE")) {
                saveCatalog.setText("Save Inventory");
            } else if (option.equals("UPDATE")) {
                saveCatalog.setText("Update Inventory");
            } else if (option.equals("DELETE")) {
                saveCatalog.setText("Delete Inventory");
                drugInfo.setEnabled(false);
                inventoryJTable.setEnabled(false);
                deleteRow.setEnabled(false);
                updateDrugValues.setEnabled(false);
                drugCatDrugList.setEnabled(false);

            }
        } catch (Exception e) {
        }
    }

    //Refresh Table data
    private void refreshTable() {
        try {
            DefaultTableModel dtm = (DefaultTableModel) inventoryJTable.getModel();
            dtm.setRowCount(0);
            for (DrugItem dr : drugInv.getDrugItemList()) {
                Object row[] = new Object[4];
                row[0] = dr;
                row[1] = dr.getDrugInfo().getDrugName();
                row[2] = dr.getQuantity();
                row[3] = dr.getSellPrice();
                dtm.addRow(row);
            }
        } catch (Exception e) {
        }
    }

    //Add drugitem to table
    private void addToTable(DrugItem d) {
        try {
            int rows = inventoryJTable.getRowCount();
            DrugItem dr;
            boolean isAlready = false;
            for (int i = 0; i < rows; i++) {
                dr = (DrugItem) inventoryJTable.getValueAt(i, 0);
                // System.out.println(dr.getDrugInfo().getDrugId());
                if (dr.getDrugInfo().getDrugId().equals(d.getDrugInfo().getDrugId())) {
                    isAlready = true;
                    break;
                }
            }
            if (isAlready) {
                JOptionPane.showMessageDialog(null, "Cannot add same drug again. You can update.", "DUPLICATE!!", JOptionPane.INFORMATION_MESSAGE);
            } else if (checkItemIdNumber(itemIdText.getText().trim())) {
                DefaultTableModel dtm = (DefaultTableModel) inventoryJTable.getModel();
                Object row[] = new Object[4];
                row[0] = d;
                row[1] = d.getDrugInfo().getDrugName();
                row[2] = d.getQuantity();
                row[3] = d.getSellPrice();
                dtm.addRow(row);
                drugInv.addDrugtoInventory(d);
            } else {
                JOptionPane.showMessageDialog(null, "Select row / Update item Id.", "DUPLICATE!!", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (Exception e) {
        }
    }

    //Load drug list
    private void loadDrugs() {
        for (Drug d : drugList.getDrugCatalog()) {
            drugCatDrugList.addItem(d.getDrugName());
        }

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        drugCatDrugList = new javax.swing.JComboBox();
        jLabel1 = new javax.swing.JLabel();
        addToCatalog = new javax.swing.JButton();
        saveCatalog = new javax.swing.JButton();
        deleteRow = new javax.swing.JButton();
        drugInfo = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        nameText = new javax.swing.JTextField();
        drugTypeText = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        dosageText = new javax.swing.JTextField();
        colourText = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        categoryText = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        descriptionText = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        warningText = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        idText = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        manufacturerText = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        presPref = new javax.swing.JComboBox();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        priceText = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        quantity = new javax.swing.JTextField();
        jLabel18 = new javax.swing.JLabel();
        sellPrice = new javax.swing.JTextField();
        jLabel19 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        itemIdText = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        supplierList1 = new javax.swing.JComboBox();
        jLabel14 = new javax.swing.JLabel();
        updateDrugValues = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        inventoryJTable = new javax.swing.JTable();
        jButton3 = new javax.swing.JButton();
        jLabel20 = new javax.swing.JLabel();
        storeNumber = new javax.swing.JLabel();

        setBackground(new java.awt.Color(244, 237, 226));

        drugCatDrugList.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel1.setText("Drug List");

        addToCatalog.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        addToCatalog.setForeground(new java.awt.Color(153, 0, 0));
        addToCatalog.setText("Add to Inventory >>");
        addToCatalog.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addToCatalogActionPerformed(evt);
            }
        });

        saveCatalog.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        saveCatalog.setForeground(new java.awt.Color(153, 0, 0));
        saveCatalog.setText("Save Inventory");
        saveCatalog.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveCatalogActionPerformed(evt);
            }
        });

        deleteRow.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        deleteRow.setForeground(new java.awt.Color(153, 0, 0));
        deleteRow.setText("Delete Item from Inventory");
        deleteRow.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteRowActionPerformed(evt);
            }
        });

        drugInfo.setBackground(new java.awt.Color(244, 237, 226));
        drugInfo.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel3.setText("Name");

        nameText.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        nameText.setEnabled(false);

        drugTypeText.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        drugTypeText.setEnabled(false);

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel4.setText("Drug Type");

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel5.setText("Dosage");

        dosageText.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        dosageText.setEnabled(false);

        colourText.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        colourText.setEnabled(false);

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel6.setText("Colour");

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel7.setText("Category");

        categoryText.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        categoryText.setEnabled(false);

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel8.setText("Description");

        descriptionText.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        descriptionText.setEnabled(false);

        jLabel9.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel9.setText("Warning");

        warningText.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        warningText.setEnabled(false);

        jLabel10.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel10.setText("Id");

        idText.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        idText.setEnabled(false);

        jLabel11.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel11.setText("Manufacturer");

        manufacturerText.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        manufacturerText.setEnabled(false);

        jLabel13.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel13.setText("Prescription Only");

        presPref.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        presPref.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Yes", "No" }));
        presPref.setEnabled(false);

        jLabel15.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel15.setText("Add Drug Details");

        jLabel16.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel16.setText("Price");

        priceText.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        priceText.setText("0.0");
        priceText.setEnabled(false);
        priceText.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                priceTextActionPerformed(evt);
            }
        });

        jLabel17.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel17.setText("Quantity");

        quantity.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        quantity.setText("0");
        quantity.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                quantityKeyTyped(evt);
            }
        });

        jLabel18.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel18.setText("Selling Price");

        sellPrice.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        sellPrice.setText("0.0");
        sellPrice.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                sellPriceKeyTyped(evt);
            }
        });

        jLabel19.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel19.setText("Drug Information");

        jLabel21.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel21.setText("Item Id");

        itemIdText.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        javax.swing.GroupLayout drugInfoLayout = new javax.swing.GroupLayout(drugInfo);
        drugInfo.setLayout(drugInfoLayout);
        drugInfoLayout.setHorizontalGroup(
            drugInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(drugInfoLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(drugInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(drugInfoLayout.createSequentialGroup()
                        .addGroup(drugInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel13)
                            .addComponent(jLabel16)
                            .addComponent(jLabel3)
                            .addComponent(jLabel10)
                            .addComponent(jLabel11))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(drugInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(nameText, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(idText, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 275, Short.MAX_VALUE)
                            .addComponent(presPref, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(manufacturerText, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(priceText, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 204, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(drugInfoLayout.createSequentialGroup()
                        .addGroup(drugInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4)
                            .addComponent(jLabel5)
                            .addComponent(jLabel6)
                            .addComponent(jLabel7)
                            .addComponent(jLabel8)
                            .addComponent(jLabel9))
                        .addGap(7, 7, 7)
                        .addGroup(drugInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(drugTypeText, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(dosageText, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(colourText, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 321, Short.MAX_VALUE)
                            .addComponent(categoryText, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(descriptionText, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(warningText, javax.swing.GroupLayout.Alignment.TRAILING)))
                    .addGroup(drugInfoLayout.createSequentialGroup()
                        .addGroup(drugInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(drugInfoLayout.createSequentialGroup()
                                .addComponent(jLabel19)
                                .addGap(0, 240, Short.MAX_VALUE))
                            .addGroup(drugInfoLayout.createSequentialGroup()
                                .addGroup(drugInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel15)
                                    .addComponent(jLabel17)
                                    .addComponent(jLabel18)
                                    .addComponent(jLabel21))
                                .addGap(7, 7, 7)
                                .addGroup(drugInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(itemIdText)
                                    .addComponent(quantity, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(sellPrice, javax.swing.GroupLayout.Alignment.TRAILING))))
                        .addContainerGap())))
        );
        drugInfoLayout.setVerticalGroup(
            drugInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(drugInfoLayout.createSequentialGroup()
                .addGap(8, 8, 8)
                .addComponent(jLabel15)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(drugInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel17)
                    .addComponent(quantity, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(drugInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel18)
                    .addComponent(sellPrice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10)
                .addGroup(drugInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel21)
                    .addComponent(itemIdText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel19)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(drugInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(nameText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(drugInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(idText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(drugInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13)
                    .addComponent(presPref, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(drugInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(manufacturerText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(drugInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel16)
                    .addComponent(priceText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(drugInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(drugTypeText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(drugInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(dosageText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(drugInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(colourText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(drugInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(categoryText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(drugInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(descriptionText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(drugInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(warningText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel12.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel12.setText("Department");

        supplierList1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        supplierList1.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Pharmacy" }));
        supplierList1.setEnabled(false);

        jLabel14.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(153, 0, 0));
        jLabel14.setText("Inventory Manager");

        updateDrugValues.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        updateDrugValues.setForeground(new java.awt.Color(153, 0, 0));
        updateDrugValues.setText("<< Update");
        updateDrugValues.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateDrugValuesActionPerformed(evt);
            }
        });

        inventoryJTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Id", "Drug Name", "Quantity", "Selling Price"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(inventoryJTable);
        if (inventoryJTable.getColumnModel().getColumnCount() > 0) {
            inventoryJTable.getColumnModel().getColumn(0).setResizable(false);
            inventoryJTable.getColumnModel().getColumn(1).setResizable(false);
            inventoryJTable.getColumnModel().getColumn(2).setResizable(false);
        }

        jButton3.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jButton3.setForeground(new java.awt.Color(153, 0, 51));
        jButton3.setText("<< Back");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jLabel20.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(153, 0, 0));
        jLabel20.setText("Store");

        storeNumber.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        storeNumber.setText("storeNo");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jButton3)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel14)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel12)
                        .addGap(18, 18, 18)
                        .addComponent(supplierList1, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addGap(34, 34, 34)
                                .addComponent(drugCatDrugList, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(drugInfo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(updateDrugValues, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(36, 36, 36)
                                .addComponent(deleteRow))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(121, 121, 121)
                                .addComponent(jLabel20)
                                .addGap(18, 18, 18)
                                .addComponent(storeNumber))
                            .addGroup(layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(addToCatalog, javax.swing.GroupLayout.PREFERRED_SIZE, 347, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(118, 118, 118)
                                .addComponent(saveCatalog)))))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(storeNumber)
                    .addComponent(jLabel20)
                    .addComponent(jButton3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(jLabel14)
                    .addComponent(jLabel12)
                    .addComponent(supplierList1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(jLabel1)
                    .addComponent(drugCatDrugList, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(addToCatalog)
                        .addGap(36, 36, 36)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(deleteRow)
                            .addComponent(updateDrugValues))
                        .addGap(87, 87, 87)
                        .addComponent(saveCatalog)
                        .addGap(91, 91, 91))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(drugInfo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void addToCatalogActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addToCatalogActionPerformed
        // TODO add your handling code here:
        try {
            if (idText.getText().trim().isEmpty() || quantity.getText().trim().isEmpty() || sellPrice.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Enter values properly");
                return;
            } else {
                Drug d = getValuesFromFields();
                DrugItem di = createDrugItem(d);
                addToTable(di);
                //resetFields();
            }
        } catch (Exception e) {
        }
    }//GEN-LAST:event_addToCatalogActionPerformed
    boolean textBoxCheckerEmpty(JTextField txtBox) {
        if (txtBox.getText().isEmpty()) {
            txtBox.setBackground(Color.YELLOW);
            return true;
        } else {
            txtBox.setBackground(Color.WHITE);
            return false;
        }
    }

    //Store drug item 
    public DrugItem createDrugItem(Drug d) {
        DrugItem dii = new DrugItem();
        dii.setDrugInfo(d);
        dii.setQuantity(Integer.parseInt(quantity.getText()));
        dii.setSellPrice(Float.parseFloat(sellPrice.getText()));
        System.out.println(dii.getSellPrice());
        dii.setItemId(itemIdText.getText());
        return dii;
    }

    //Drug list
    private void configureDrugListCombo() {
        ItemListener itemLis = new ItemListener() {

            @Override
            public void itemStateChanged(ItemEvent e) {
                int state = e.getStateChange();
                if (state == ItemEvent.SELECTED) {
                    String supName = (String) drugCatDrugList.getSelectedItem();
                    loadDrug(supName);
                }
            }

        };
        drugCatDrugList.addItemListener(itemLis);
    }

    //Load drug
    public void loadDrug(String drugName) {
        Drug d = null;
        //    productList.removeAllItems();
        for (Drug x : drugList.getDrugCatalog()) {
            if (x.getDrugName().equals(drugName)) {
                d = x;
                break;
            }
        }
        if (d != null) {
            setValuesInDrugPanel(d);
        }
    }

    private Product getSelectedProd(String selProdName, ArrayList<Product> pc) {
        Product sel = null;
        for (Product p1 : pc) {
            if (p1.getProductName().equals(selProdName)) {
                sel = p1;
                break;
            }
        }
        return sel;
    }

    private void setValuesInDrugPanel(Drug d) {
        setValuesToFields(d);
    }
    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        userProcessContainer.remove(this);
        Component[] componentArray = userProcessContainer.getComponents();
        Component component = componentArray[componentArray.length - 1];
        ManageDrugInvWorkArea panel = (ManageDrugInvWorkArea) component;
        panel.enableDisableLogic();

        CardLayout layout = (CardLayout) userProcessContainer.getLayout();
        layout.previous(userProcessContainer);
    }//GEN-LAST:event_jButton3ActionPerformed

    private void deleteRowActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteRowActionPerformed
        // TODO add your handling code here:
        int selectedRow = inventoryJTable.getSelectedRow();
        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(this, "Select one row from table");
            return;
        }
        DrugItem dr = (DrugItem) inventoryJTable.getValueAt(selectedRow, 0);
        drugInv.deleteDrugFromInv(dr);
        refreshTable();
    }//GEN-LAST:event_deleteRowActionPerformed

    private void saveCatalogActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveCatalogActionPerformed
        // TODO add your handling code here:
        try {
            if (drugInv.getDrugItemList().size() < 1) {
                JOptionPane.showMessageDialog(this, "No drug in inventory. Please add some drug items before saving");
                return;
            }
            switch (option) {
                case "CREATE":
                    mainInventory.setDrugItemList(new ArrayList<>());
                    for (DrugItem d : drugInv.getDrugItemList()) {
                        mainInventory.addDrugtoInventory(d);
                    }
                    JOptionPane.showMessageDialog(this, "Saved succesfully");
                    saveCatalog.setEnabled(false);
                    deleteRow.setEnabled(false);
                    updateDrugValues.setEnabled(false);
                    drugInfo.setEnabled(false);
                    addToCatalog.setEnabled(false);
                    break;
                case "UPDATE":
                    mainInventory.setDrugItemList(new ArrayList<>());
                    for (DrugItem d : drugInv.getDrugItemList()) {
                        mainInventory.addDrugtoInventory(d);
                    }
                    JOptionPane.showMessageDialog(this, "Updated succesfully");
                    copyToLocalInventory();
                    refreshTable();
                    break;
                case "DELETE":
                    int response = JOptionPane.showConfirmDialog(null, "Do you want to this Store inventory", "Confirm", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
                    if (response == JOptionPane.YES_OPTION) {
                        mainInventory.setDrugItemList(new ArrayList<>());
                        drugInv.setDrugItemList(new ArrayList<>());
                        JOptionPane.showMessageDialog(this, "Deleted succesfully. Go back to create a new inventory");
                        refreshTable();
                        saveCatalog.setEnabled(false);
                    }
            }
        } catch (Exception e) {
        }

    }//GEN-LAST:event_saveCatalogActionPerformed

    private void updateDrugValuesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateDrugValuesActionPerformed
        // TODO add your handling code here:
        int selectedRow = inventoryJTable.getSelectedRow();
        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(this, "Select one drug item from inventory");
            return;
        }
        //now change the values
        DrugItem dr = (DrugItem) inventoryJTable.getValueAt(selectedRow, 0);
        setValuesToFields(dr.getDrugInfo());
        quantity.setText(String.valueOf(dr.getQuantity()));
        sellPrice.setText(String.valueOf(dr.getSellPrice()));
        itemIdText.setText(dr.getItemId());
        drugInv.deleteDrugFromInv(dr);
        refreshTable();
    }//GEN-LAST:event_updateDrugValuesActionPerformed

    private void priceTextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_priceTextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_priceTextActionPerformed

    private void sellPriceKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_sellPriceKeyTyped
        // TODO add your handling code here:
        char key = evt.getKeyChar();
        if (!(Character.isDigit(key) || key == '.')) {
            evt.consume();
        }
    }//GEN-LAST:event_sellPriceKeyTyped

    private void quantityKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_quantityKeyTyped
        // TODO add your handling code here:
        char key = evt.getKeyChar();
        if (!(Character.isDigit(key))) {
            evt.consume();
        }
    }//GEN-LAST:event_quantityKeyTyped

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addToCatalog;
    private javax.swing.JTextField categoryText;
    private javax.swing.JTextField colourText;
    private javax.swing.JButton deleteRow;
    private javax.swing.JTextField descriptionText;
    private javax.swing.JTextField dosageText;
    private javax.swing.JComboBox drugCatDrugList;
    private javax.swing.JPanel drugInfo;
    private javax.swing.JTextField drugTypeText;
    private javax.swing.JTextField idText;
    private javax.swing.JTable inventoryJTable;
    private javax.swing.JTextField itemIdText;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField manufacturerText;
    private javax.swing.JTextField nameText;
    private javax.swing.JComboBox presPref;
    private javax.swing.JTextField priceText;
    private javax.swing.JTextField quantity;
    private javax.swing.JButton saveCatalog;
    private javax.swing.JTextField sellPrice;
    private javax.swing.JLabel storeNumber;
    private javax.swing.JComboBox supplierList1;
    private javax.swing.JButton updateDrugValues;
    private javax.swing.JTextField warningText;
    // End of variables declaration//GEN-END:variables

    private Drug getValuesFromFields() {
        Drug d = new Drug();
        d.setDrugName(nameText.getText());
        d.setDrugId(idText.getText());
        d.setManufacturer(manufacturerText.getText());
        d.setPrice(Float.parseFloat(priceText.getText()));
        d.setDrugType(drugTypeText.getText());
        d.setDosageInfo(dosageText.getText());
        d.setColour(colourText.getText());
        d.setCategory(categoryText.getText());
        d.setDrugDesc(descriptionText.getText());
        d.setDrugWarning(warningText.getText());
        if (presPref.equals("Yes")) {
            d.setIsOnlyPres(true);
        } else {
            d.setIsOnlyPres(false);
        }
        return d;
    }

    private void setValuesToFields(Drug d) {
        nameText.setText(d.getDrugName());
        idText.setText(d.getDrugId());
        manufacturerText.setText(d.getManufacturer());
        priceText.setText(String.valueOf(d.getPrice()));
        drugTypeText.setText(d.getDrugType());
        dosageText.setText(d.getDosageInfo());
        colourText.setText(d.getColour());
        categoryText.setText(d.getCategory());
        descriptionText.setText(d.getDrugDesc());
        warningText.setText(d.getDrugWarning());
        if (d.getIsOnlyPres()) {
            presPref.setSelectedItem("Yes");
        } else {
            presPref.setSelectedItem("No");
        }

    }

    private void copyToLocalInventory() {
        drugInv = new DrugInventory();
        for (DrugItem d : mainInventory.getDrugItemList()) {
            drugInv.addDrugtoInventory(d);
        }
    }

    private void resetFields() {
        quantity.setText("0");
        sellPrice.setText("0.0");
        itemIdText.setText("");
        nameText.setText("");
        idText.setText("");
        manufacturerText.setText("");
        priceText.setText(String.valueOf(""));
        drugTypeText.setText("");
        dosageText.setText("");
        colourText.setText("");
        categoryText.setText("");
        descriptionText.setText("");
        warningText.setText("");
        presPref.setSelectedItem("Yes");
    }

    private boolean checkItemIdNumber(String id) {
        int rows = inventoryJTable.getRowCount();
        if (rows == 0) {
            return true;
        }
        DrugItem dr = null;
        boolean isAlready = false;
        for (int i = 0; i < rows; i++) {
            dr = (DrugItem) inventoryJTable.getValueAt(i, 0);
            System.out.println(dr.getItemId() + "drugIDDD");
            if (dr.getItemId().trim().equals(id)) {
                isAlready = true;
                break;
            }
        }
        return !isAlready;
    }
}

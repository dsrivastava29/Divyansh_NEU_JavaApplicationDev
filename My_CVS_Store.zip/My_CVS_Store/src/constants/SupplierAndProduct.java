/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package constants;

/**
 * Static data
 *
 * @author Divyansh
 */
public class SupplierAndProduct {

    public static String suppNames[] = {"Pfizer", "Novartis", "Sanofi", "AstraZeneca", "GlaxoSmithKline"};
    public static String Pfizer_ProList[][] = {{"Antivenin", "49"},
    {"Aricept", "59"},
    {"Avinza", "69"},
    {"Bosulif", "79"},
    {"Relpax", "29"},
    {"Revatio", "77"},
    {"Oxecta", "88"},
    {"Lincocin", "99"},
    {"Nardil", "67"},
    {"Tigan", "56"}};
    public static String Novartis_ProList[][] = {{"Novartis a1200e", "988"},
    {"Novartis a1400", "89"},
    {"Novartis a6000", "56"},
    {"Novartis a1500", "56"},
    {"Novartis a1330e", "88"},
    {"Novartis dv9000", "99"},
    {"Novartis  s7300 ", "89"},
    {"Novartis s1000", "67"},
    {"Novartis  s7600 ", "45"},
    {"Novartis dv9000", "98"},};
    public static String Sanofi_ProList[][] = {{"Sanofi 35", "78"},
    {"Sanofi 3330", "89"},
    {"Satellite C50", "90"},
    {"BCNT 01", "34"},
    {"SanofiBETA 2", "76"},
    {"B5298", "89"},
    {"CBT2N01", "67"},
    {"Sanofi 11", "89"},
    {"CB32", "99"},
    {"BBT2N11", "39"},};
    public static String AstraZeneca_ProList[][] = {{"Astra 5", "78"},
    {"Astra touch", "89"},
    {"Astra Nano", "99"},
    {"Astra Book Pro", "90"},
    {"Astra Mini", "78"},
    {"Astra air", "90"},
    {"Astra Air", "78"},
    {"Astra Pro", "98"},
    {"Astra 4", "56"},
    {"Astra 6S", "90"},};
    public static String GlaxoSmithKline_ProList[][] = {{"100 Glaco", "56"},
    {"500 Glaco", "54"},
    {"B Glaco", "67"},
    {"Flex Glaco", "88"},
    {"G Glaco", "35"},
    {"S Glaco", "57"},
    {"U Glaco", "77"},
    {"Y Glaco", "87"},
    {"Z Glaco", "98"},
    {"X Glaco", "90"},};

}

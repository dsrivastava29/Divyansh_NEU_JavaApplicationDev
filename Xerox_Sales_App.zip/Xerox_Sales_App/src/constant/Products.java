/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package constant;

/**
 * Products Information for catalog
 *
 * @author Divyansh
 */
public class Products {

    public static String listNames[] = {"list1", "list2", "list3", "list4"};
    public static String list1[][] = {{"Kevenin", "49", "44", "55"},
    {"Aricept", "59", "54", "66"},
    {"Avinza", "69", "59", "75"},
    {"Bosulif", "79", "69", "89"},
    {"Relpax", "29", "59", "59"},
    {"Revatio", "77", "60", "89"},
    {"Oxecta", "88", "79", "99"},
    {"Lincocin", "99", "89", "109"},
    {"Nardil", "67", "59", "79"},
    {"Tigan", "56", "49", "69"}};
    public static String list2[][] = {{"hsdjvenin", "49", "44", "55"},
    {"gercept", "59", "54", "66"},
    {"nagnza", "69", "59", "75"},
    {"LKHulif", "79", "69", "89"},
    {"Rhkpax", "29", "59", "59"},
    {"cgbatio", "77", "60", "89"},
    {"opiucta", "88", "79", "99"},
    {"qqwcocin", "99", "89", "109"},
    {"tfhdil", "67", "59", "79"},
    {"ligan", "56", "49", "69"}};
    public static String list3[][] = {{"venin", "49", "44", "55"},
    {"Cept", "59", "54", "66"},
    {"Inza", "69", "59", "75"},
    {"Osulif", "79", "69", "89"},
    {"Pax", "29", "59", "59"},
    {"Atio", "77", "60", "89"},
    {"Ecta", "88", "79", "99"},
    {"Cocin", "99", "89", "109"},
    {"Ardil", "67", "59", "79"},
    {"Gaan", "56", "49", "69"}};

}

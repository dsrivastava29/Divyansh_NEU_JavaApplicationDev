/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business.sales;

import business.orders.Order;
import business.users.Person;
import java.util.ArrayList;

/**
 * Sales person class
 *
 * @author Divyansh
 */
public class SalesPerson {

    private static int count = 0;
    private int salesPersonId;
    private float commision;
    private Person person;
    private ArrayList<Order> salesOrderList;

    public SalesPerson() {
        salesPersonId = ++count;
        salesOrderList = new ArrayList<>();
        person = new Person();
    }

    public int qtyAboveTarget() {
        int q = 0;
        for (Order ord : salesOrderList) {
            q += ord.qtyAboveTarget();
        }
        return q;
    }

    public int qtyBelowTarget() {
        int q = 0;
        for (Order ord : salesOrderList) {
            q += ord.qtyBelowTarget();
        }
        return q;
    }

    public int qtySold() {
        int qty = 0;
        for (Order o : salesOrderList) {
            qty += o.getQtyByVolume();
            System.out.println(qty);
        }
        System.out.println(person.getfName());
        return qty;
    }

    public float totalCommisionPaid() {
        float cmpaid = 0.0f;
        for (Order o : salesOrderList) {
            cmpaid += o.getOrderCommision();
            System.out.println(cmpaid);
        }
        return cmpaid;
    }

    public float getCommision() {
        return commision;
    }

    public void setCommision(float commision) {
        this.commision = commision;
    }

    @Override
    public String toString() {
        return salesPersonId + "";
    }

    public static int getCount() {
        return count;
    }

    public static void setCount(int count) {
        SalesPerson.count = count;
    }

    public int getSalesPersonId() {
        return salesPersonId;
    }

    public void setSalesPersonId(int salesPersonId) {
        this.salesPersonId = salesPersonId;
    }

    public Person getPerson() {
        return person;
    }

    public void setPerson(Person person) {
        this.person = person;
    }

    public ArrayList<Order> getSalesOrderList() {
        return salesOrderList;
    }

    public void setSalesOrderList(ArrayList<Order> salesOrderList) {
        this.salesOrderList = salesOrderList;
    }

    public Order addNewOrder() {
        Order o = new Order();
        salesOrderList.add(o);
        return o;
    }
}

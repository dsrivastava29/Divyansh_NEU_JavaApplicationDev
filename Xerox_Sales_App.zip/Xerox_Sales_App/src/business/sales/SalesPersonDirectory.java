/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business.sales;

import java.util.ArrayList;

/**
 * List of all sales persons in Xerox
 *
 * @author Divyansh
 */
public class SalesPersonDirectory {

    private ArrayList<SalesPerson> salesPersons;

    public SalesPersonDirectory() {
        salesPersons = new ArrayList<>();
    }

    public ArrayList<SalesPerson> getSalesPersons() {
        return salesPersons;
    }

    public void setSalesPersons(ArrayList<SalesPerson> salesPersons) {
        this.salesPersons = salesPersons;
    }

    public SalesPerson addSalesPerson() {
        SalesPerson sp = new SalesPerson();
        salesPersons.add(sp);
        return sp;
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business.orders;

import java.util.ArrayList;

/**
 * One order placed by Sales for Customer
 *
 * @author Divyansh
 */
public class Order {

    private static int orderCount = 0;
    private int orderId;
    private ArrayList<OrderItem> orderItems;
    private int customerId;
    private int salesPersonId;
    private String status;
    public static String STARTED = "started";
    //private final String PLACED="started";
    public static String COMPLETED = "completed";

    public Order() {
        orderId = ++orderCount;
        orderItems = new ArrayList<>();
        status = STARTED;
    }

    public int qtyAboveTarget() {
        int q = 0;
        for (OrderItem o : orderItems) {
            if (o.isAboveTarget()) {
                q += o.getQuantity();
            }
        }
        return q;
    }

    public int qtyBelowTarget() {
        int q = 0;
        for (OrderItem o : orderItems) {
            if (!(o.isAboveTarget())) {
                q += o.getQuantity();
            }
        }
        return q;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public int getSalesPersonId() {
        return salesPersonId;
    }

    public void setSalesPersonId(int salesPersonId) {
        this.salesPersonId = salesPersonId;
    }

    public static int getOrderCount() {
        return orderCount;
    }

    public static void setOrderCount(int orderCount) {
        Order.orderCount = orderCount;
    }

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public ArrayList<OrderItem> getOrderItems() {
        return orderItems;
    }

    public void setOrderItems(ArrayList<OrderItem> orderItems) {
        this.orderItems = orderItems;
    }

    public void addNewOrderItem(OrderItem oi) {
        orderItems.add(oi);
    }

    public int getQtyByVolume() {
        int vol = 0;
        for (OrderItem i : orderItems) {
            vol += i.getQuantity();
        }
        return vol;
    }

    public float getOrderCommision() {
        float volcm = 0.0f;
        for (OrderItem i : orderItems) {
            volcm += i.getCommision();
        }
        return volcm;
    }
}

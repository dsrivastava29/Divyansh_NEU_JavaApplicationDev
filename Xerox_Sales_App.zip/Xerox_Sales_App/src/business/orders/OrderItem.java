/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business.orders;

/**
 * Order Item -each item has one product and no of quantities
 *
 * @author Divyansh
 */
public class OrderItem {

    private static int count = 0;
    private int ItemId;
    private float sellPrice;
    private int quantity;
    private float actualPrice;
    private String prodName;
    private float commision;

    public boolean isAboveTarget() {
        if (sellPrice > actualPrice) {
            return true;
        } else {
            return false;
        }
    }

    public float getCommision() {
        return commision;
    }

    public void setCommision(float commision) {
        this.commision = commision;
    }

    public float getActualPrice() {
        return actualPrice;
    }

    public void setActualPrice(float actualPrice) {
        this.actualPrice = actualPrice;
    }

    public OrderItem() {
        ItemId = ++count;
    }

    @Override
    public String toString() {
        return "" + ItemId;
    }

    public String getProdName() {
        return prodName;
    }

    public void setProdName(String prodName) {
        this.prodName = prodName;
    }

    public static int getCount() {
        return count;
    }

    public static void setCount(int count) {
        OrderItem.count = count;
    }

    public int getItemId() {
        return ItemId;
    }

    public void setItemId(int ItemId) {
        this.ItemId = ItemId;
    }

    public float getSellPrice() {
        return sellPrice;
    }

    public void setSellPrice(float sellPrice) {
        this.sellPrice = sellPrice;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public float calculateTotal() {
        return quantity * sellPrice;
    }
}

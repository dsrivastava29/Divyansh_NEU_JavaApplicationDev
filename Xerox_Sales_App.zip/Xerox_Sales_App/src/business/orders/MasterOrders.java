/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business.orders;

import java.util.ArrayList;

/**
 * All orders of Xerox
 *
 * @author Divyansh
 */
public class MasterOrders {

    private ArrayList<Order> masterOrderList;

    public MasterOrders() {
        masterOrderList = new ArrayList<>();
    }

    public ArrayList<Order> getMasterOrderList() {
        return masterOrderList;
    }

    public void setMasterOrderList(ArrayList<Order> masterOrderList) {
        this.masterOrderList = masterOrderList;
    }

}

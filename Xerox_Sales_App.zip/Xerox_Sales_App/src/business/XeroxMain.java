/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business;

import business.customer.CustomerDirectory;
import business.orders.MasterOrders;
import business.products.ProductCatalog;
import business.sales.SalesPersonDirectory;
import business.users.UserAccountDirectory;

/**
 * Xerox singleton class
 *
 * @author Divyansh
 */
public class XeroxMain {

    private static XeroxMain mBusiness;
    private CustomerDirectory customerDirectory;
    private SalesPersonDirectory salesPersonDirectory;
    private UserAccountDirectory userAccountDirectory;
    private MasterOrders masterOrderList;
    private ProductCatalog productCatalog;

    private XeroxMain() {
        this.customerDirectory = new CustomerDirectory();
        this.salesPersonDirectory = new SalesPersonDirectory();
        this.userAccountDirectory = new UserAccountDirectory();
        this.masterOrderList = new MasterOrders();
        this.productCatalog = new ProductCatalog();
    }

    public static XeroxMain getBusinessInstance() {
        if (mBusiness == null) {
            mBusiness = new XeroxMain();
        }
        return mBusiness;

    }

    public CustomerDirectory getCustomerDirectory() {
        return customerDirectory;
    }

    public void setCustomerDirectory(CustomerDirectory customerDirectory) {
        this.customerDirectory = customerDirectory;
    }

    public SalesPersonDirectory getSalesPersonDirectory() {
        return salesPersonDirectory;
    }

    public void setSalesPersonDirectory(SalesPersonDirectory salesPersonDirectory) {
        this.salesPersonDirectory = salesPersonDirectory;
    }

    public UserAccountDirectory getUserAccountDirectory() {
        return userAccountDirectory;
    }

    public void setUserAccountDirectory(UserAccountDirectory userAccountDirectory) {
        this.userAccountDirectory = userAccountDirectory;
    }

    public MasterOrders getMasterOrderList() {
        return masterOrderList;
    }

    public void setMasterOrderList(MasterOrders masterOrderList) {
        this.masterOrderList = masterOrderList;
    }

    public ProductCatalog getProductCatalog() {
        return productCatalog;
    }

    public void setProductCatalog(ProductCatalog productCatalog) {
        this.productCatalog = productCatalog;
    }

}

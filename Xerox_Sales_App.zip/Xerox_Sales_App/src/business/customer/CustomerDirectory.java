/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business.customer;

import java.util.ArrayList;

/**
 * List of customers
 *
 * @author Divyansh
 */
public class CustomerDirectory {

    private ArrayList<Customer> customerDirectory;

    public CustomerDirectory() {
        customerDirectory = new ArrayList<>();
    }

    public String getMostPopular() {
        int max = 0;
        Customer maxP = null;
        try {
            for (Customer p : customerDirectory) {

                if (p.getSalesByVolume() > max) {
                    maxP = p;
                    max = p.getSalesByVolume();
                }
            }
        } catch (Exception e) {
        }
        if (maxP != null) {
            return maxP.getPerson().toString();
        } else {
            return null;
        }
    }

    public ArrayList<Customer> getCustomerDirectory() {
        return customerDirectory;
    }

    public void setCustomerDirectory(ArrayList<Customer> customerDirectory) {
        this.customerDirectory = customerDirectory;
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business.customer;

import business.orders.Order;
import business.users.Person;
import java.util.ArrayList;

/**
 * Customer Information
 *
 * @author Divyansh
 */
public class Customer {

    private static int count = 5000;
    private Person person;
    private String organization;
    private int customerId;
    //List of orders
    private ArrayList<Order> myOrders;

    public ArrayList<Order> getMyOrders() {
        return myOrders;
    }

    public void setMyOrders(ArrayList<Order> myOrders) {
        this.myOrders = myOrders;
    }

    public Customer() {
        person = new Person();
        customerId = ++count;
        myOrders = new ArrayList<>();
    }

    @Override
    public String toString() {
        return "" + person.getfName() + " " + person.getlName();
    }

    public Person getPerson() {
        return person;
    }

    public void setPerson(Person person) {
        this.person = person;
    }

    public String getOrganization() {
        return organization;
    }

    public void setOrganization(String organization) {
        this.organization = organization;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public void addOrder(Order o) {
        this.myOrders.add(o);
    }

    public int getSalesByVolume() {
        int vol = 0;
        try {
            for (Order o : getMyOrders()) {
                vol += o.getQtyByVolume();
            }
        } catch (Exception e) {
        }
        return vol;
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business.users;

import java.util.ArrayList;

/**
 * List of users
 *
 * @author Divyansh
 */
public class UserAccountDirectory {

    private ArrayList<UserAccount> userAccountList;

    public UserAccountDirectory() {
        userAccountList = new ArrayList<>();
    }

    public UserAccount addUserAccount() {
        UserAccount e = new UserAccount();
        userAccountList.add(e);
        return e;
    }

    public ArrayList<UserAccount> getUsersForRole(String role) {
        ArrayList<UserAccount> sub = new ArrayList<>();
        System.out.println(role);
//        if(userAccountList.size()==1)
//            return sub;        
        for (UserAccount u : userAccountList) {
            if (u.getRole().equals(role)) {
                sub.add(u);
            }
        }
        return sub;
    }

    public void deleteUserAccount(UserAccount e) {
        userAccountList.remove(e);
    }

    public ArrayList<UserAccount> getUserAccountList() {
        return userAccountList;
    }

    public void setUserAccountList(ArrayList<UserAccount> userAccountList) {
        this.userAccountList = userAccountList;
    }

    public void updateUser(UserAccount old, UserAccount ua) {
        int index = userAccountList.indexOf(old);
        userAccountList.set(index, ua);
    }

    public UserAccount getSelectedUser(UserAccount selU) {
        return userAccountList.get(userAccountList.indexOf(selU));
    }
}

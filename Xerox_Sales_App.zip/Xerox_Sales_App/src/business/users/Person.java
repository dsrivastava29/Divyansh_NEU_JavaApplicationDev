/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business.users;

/**
 * Individual person
 *
 * @author Divyansh
 */
public class Person {

    private static int id = 0;
    private String fName;
    private String lName;

    @Override
    public String toString() {
        return fName + " " + lName;
    }

    public static int getId() {
        return id;
    }

    public String getfName() {
        return fName;
    }

    public void setfName(String fName) {
        this.fName = fName;
    }

    public String getlName() {
        return lName;
    }

    public void setlName(String lName) {
        this.lName = lName;
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business.products;

import business.orders.OrderItem;
import java.util.ArrayList;

/**
 * Product Info
 *
 * @author Divyansh
 */
public class Product {

    private static int count = 1000;
    private int prodId;
    private String prodName;

    public ArrayList<OrderItem> getProdOrderItems() {
        return prodOrderItems;
    }

    public void setProdOrderItems(ArrayList<OrderItem> prodOrderItems) {
        this.prodOrderItems = prodOrderItems;
    }
    private float floorPrice;
    private float targetPrice;
    private float ceilingPrice;
    private ArrayList<OrderItem> prodOrderItems;

    public Product() {
        prodId = ++count;
        prodOrderItems = new ArrayList<>();
    }

    @Override
    public String toString() {
        return prodName;
    }

    public static int getCount() {
        return count;
    }

    public static void setCount(int count) {
        Product.count = count;
    }

    public int getprodId() {
        return prodId;
    }

    public void setprodId(int id) {
        this.prodId = id;
    }

    public String getProdName() {
        return prodName;
    }

    public void setProdName(String prodName) {
        this.prodName = prodName;
    }

    public float getFloorPrice() {
        return floorPrice;
    }

    public void setFloorPrice(float floorPrice) {
        this.floorPrice = floorPrice;
    }

    public float getTargetPrice() {
        return targetPrice;
    }

    public void setTargetPrice(float targetPrice) {
        this.targetPrice = targetPrice;
    }

    public float getCeilingPrice() {
        return ceilingPrice;
    }

    public void setCeilingPrice(float ceilingPrice) {
        this.ceilingPrice = ceilingPrice;
    }

    public void addProductOrderItem(OrderItem oi) {
        oi.setProdName(this.getProdName());
        prodOrderItems.add(oi);

    }

    public int getTotalSoldItems() {
        int count = 0;
        for (OrderItem o : prodOrderItems) {
            count += o.getQuantity();
        }
        return count;
    }
}

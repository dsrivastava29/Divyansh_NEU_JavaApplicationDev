/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business.products;

import java.util.ArrayList;

/**
 * Product catalog has list of products
 *
 * @author Divyansh
 */
public class ProductCatalog {

    private String catalogName;
    private ArrayList<Product> products;

    public ProductCatalog() {
        products = new ArrayList<>();
    }

    public String getCatalogName() {
        return catalogName;
    }

    public void setCatalogName(String catalogName) {
        this.catalogName = catalogName;
    }

    public ArrayList<Product> getProducts() {
        return products;
    }

    public void setProducts(ArrayList<Product> products) {
        this.products = products;
    }

    public String getMostPopular() {
        int max = 0;
        Product maxP = null;

        for (Product p : products) {
            System.out.println(p.getTotalSoldItems());
            if (p.getTotalSoldItems() > max) {
                maxP = p;
                max = p.getTotalSoldItems();
            }
        }
        if (maxP != null) {
            return maxP.getProdName();
        } else {
            return null;
        }
    }

}

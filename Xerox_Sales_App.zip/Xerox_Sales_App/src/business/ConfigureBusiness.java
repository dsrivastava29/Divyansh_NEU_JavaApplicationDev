/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business;

import business.customer.Customer;
import business.sales.SalesPerson;
import business.users.UserAccount;

/**
 * Configure business
 *
 * @author Divyansh
 */
public class ConfigureBusiness {

    public static XeroxMain intitializeBusiness() {
        XeroxMain business = XeroxMain.getBusinessInstance();
        try {

            InitializeProductsFromFile init = new InitializeProductsFromFile();
            init.setProductList(business.getProductCatalog());

            UserAccount ua = business.getUserAccountDirectory().addUserAccount();
            ua.setUserName("admin");
            ua.setPassword("admin");
            ua.setIsActive(true);
            ua.getPerson().setfName("admin");
            ua.getPerson().setlName("admin");
            ua.setRole(UserAccount.ADMIN_ROLE);

            ua = business.getUserAccountDirectory().addUserAccount();
            ua.setUserName("s");
            ua.setPassword("s");
            ua.setIsActive(true);
            ua.getPerson().setfName("sales");
            ua.getPerson().setlName("sales");
            ua.setRole(UserAccount.SALES_ROLE);
            SalesPerson sp = business.getSalesPersonDirectory().addSalesPerson();
            sp.setPerson(ua.getPerson());
            sp.setCommision(20.0f);

            ua = business.getUserAccountDirectory().addUserAccount();
            ua.setUserName("s1");
            ua.setPassword("s1");
            ua.setIsActive(true);
            ua.getPerson().setfName("sales1");
            ua.getPerson().setlName("sales1");
            ua.setRole(UserAccount.SALES_ROLE);
            sp = business.getSalesPersonDirectory().addSalesPerson();
            sp.setPerson(ua.getPerson());
            sp.setCommision(10.0f);

            ua = business.getUserAccountDirectory().addUserAccount();
            ua.setUserName("s2");
            ua.setPassword("s2");
            ua.setIsActive(true);
            ua.getPerson().setfName("sales2");
            ua.getPerson().setlName("sales2");
            ua.setRole(UserAccount.SALES_ROLE);
            sp = business.getSalesPersonDirectory().addSalesPerson();
            sp.setPerson(ua.getPerson());
            sp.setCommision(20.0f);

            ua = business.getUserAccountDirectory().addUserAccount();
            ua.setUserName("s3");
            ua.setPassword("s3");
            ua.setIsActive(true);
            ua.getPerson().setfName("sales3");
            ua.getPerson().setlName("sales3");
            ua.setRole(UserAccount.SALES_ROLE);
            sp = business.getSalesPersonDirectory().addSalesPerson();
            sp.setPerson(ua.getPerson());
            sp.setCommision(20.0f);

            Customer cus = new Customer();
            cus.setOrganization("c1");
            cus.getPerson().setfName("c1");
            cus.getPerson().setlName("c1");
            business.getCustomerDirectory().getCustomerDirectory().add(cus);

            cus = new Customer();
            cus.setOrganization("c2");
            cus.getPerson().setfName("c2");
            cus.getPerson().setlName("c2");
            business.getCustomerDirectory().getCustomerDirectory().add(cus);

            cus = new Customer();
            cus.setOrganization("c3");
            cus.getPerson().setfName("c3");
            cus.getPerson().setlName("c3");
            business.getCustomerDirectory().getCustomerDirectory().add(cus);

            cus = new Customer();
            cus.setOrganization("c4");
            cus.getPerson().setfName("c4");
            cus.getPerson().setlName("c4");
            business.getCustomerDirectory().getCustomerDirectory().add(cus);
        } catch (Exception e) {
        }
        return business;
    }

}

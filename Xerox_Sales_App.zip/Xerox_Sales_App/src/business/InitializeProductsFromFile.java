/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business;

import business.products.Product;
import business.products.ProductCatalog;
import java.util.ArrayList;

/**
 * Load products from constant file
 *
 * @author Divyansh
 */
public class InitializeProductsFromFile {

    private ArrayList<Product> productList;

    public InitializeProductsFromFile() {
        productList = new ArrayList<>();
    }

    public void setProductList(ProductCatalog prodCat) {
        prodCat.setProducts(InitializeProdList());
    }

    /**
     *
     */
    public ArrayList<Product> InitializeProdList() {
        try {
            String p1[][] = constant.Products.list1;
            String p2[][] = constant.Products.list2;
            String p3[][] = constant.Products.list3;
            for (int i = 0; i < p1.length; i++) {
                String subList[] = p1[i];
                Product p = new Product();
                p.setProdName(subList[0]);
                p.setTargetPrice(Float.parseFloat(subList[1]));
                p.setFloorPrice(Float.parseFloat(subList[2]));
                p.setCeilingPrice(Float.parseFloat(subList[3]));
                productList.add(p);
            }
            for (int i = 0; i < p2.length; i++) {
                String subList[] = p2[i];
                Product p = new Product();
                p.setProdName(subList[0]);
                p.setTargetPrice(Float.parseFloat(subList[1]));
                p.setFloorPrice(Float.parseFloat(subList[2]));
                p.setCeilingPrice(Float.parseFloat(subList[3]));
                productList.add(p);
            }
            for (int i = 0; i < p3.length; i++) {
                String subList[] = p3[i];
                Product p = new Product();
                p.setProdName(subList[0]);
                p.setTargetPrice(Float.parseFloat(subList[1]));
                p.setFloorPrice(Float.parseFloat(subList[2]));
                p.setCeilingPrice(Float.parseFloat(subList[3]));
                productList.add(p);
            }

        } catch (Exception e) {
        }
        return productList;
    }
}
